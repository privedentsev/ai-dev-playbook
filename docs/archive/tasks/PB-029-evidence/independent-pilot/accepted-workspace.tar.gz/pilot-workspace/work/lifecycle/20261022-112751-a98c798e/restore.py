#!/usr/bin/env python3
"""Автономное восстановление прерванной операции документов playbook.

Запуск: python3 restore.py — из каталога операции work/lifecycle/<op>/.
Не зависит от установленного ai-dev-playbook/scripts/: импортирует только
стандартную библиотеку. Отказ ничего не меняет и не снимает маркер.
"""
import hashlib
import json
import os
import re
import shutil
import sys
from pathlib import Path

op_dir = Path(__file__).resolve().parent
root = op_dir.parents[2]


def lock(stream):
    stream.seek(0)
    if os.name == "posix":
        import fcntl
        fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    elif os.name == "nt":
        import msvcrt
        msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)


# Живая операция держит общий gate и блокировку операции; восстановление
# разрешено только после реального прерывания, когда ОС их уже сняла.
gate_stream = (root / "work" / "gate.lock").open("a+b")
try:
    lock(gate_stream)
except OSError:
    print("Другая команда удерживает блокировку записи: восстановление "
          "запрещено, дождитесь завершения.", file=sys.stderr)
    sys.exit(1)
lock_stream = (root / "work" / "lifecycle" / "lock").open("a+b")
try:
    lock(lock_stream)
except OSError:
    print("Операция документов выполняется: восстановление запрещено, "
          "дождитесь завершения.", file=sys.stderr)
    sys.exit(1)

update_pending = root / "work" / "update" / "pending.json"
if update_pending.is_file():
    print("Обнаружен маркер незавершённого обновления: восстановление "
          "операции документов запрещено до разрешения обновления. "
          "Файлы проекта и маркер не изменены.", file=sys.stderr)
    sys.exit(1)


def fail(message):
    print(message + " Маркер незавершённой операции сохранён.", file=sys.stderr)
    sys.exit(1)


def refuse(message):
    print(message + " Файлы проекта и маркер не изменены.", file=sys.stderr)
    sys.exit(1)


def digest(path):
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


def state_of(path):
    if path.is_symlink():
        return "other"
    if path.is_file():
        return digest(path)
    if path.exists():
        return "other"
    return "absent"


def keep_conflict(target, rel):
    destination = op_dir / "conflicts" / rel
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(target), str(destination))


# Восстановление разрешено только собственной операции: маркер должен
# существовать и ссылаться на этот каталог. Чужой, отсутствующий или
# повреждённый маркер — отказ без каких-либо изменений.
pending = root / "work" / "lifecycle" / "pending.json"
if not pending.is_file():
    refuse("Нет маркера незавершённой операции: восстановление уже выполнено "
           "или не требуется.")
try:
    marker = json.loads(pending.read_text(encoding="utf-8"))
except (OSError, ValueError):
    marker = None
if not isinstance(marker, dict):
    refuse("Маркер незавершённой операции повреждён: владельца определить "
           "нельзя.")
op_ref = marker.get("op_dir")
own = (marker.get("op_id") == op_dir.name and isinstance(op_ref, str)
       and op_ref and (root / op_ref).resolve() == op_dir)
if not own:
    refuse(f"Маркер принадлежит другой операции ({marker.get('op_id')!r}): "
           f"этот пред-образ относится к операции {op_dir.name}.")

index_path = op_dir / "backup_index.json"
if not index_path.is_file():
    # Индекс создаётся строго до первой записи в проект, а событие
    # 'backup_complete' журналируется после его записи: журнал из одних
    # 'start'/'staged' доказывает, что файлы проекта не трогались. Любое
    # более позднее событие при отсутствующем индексе — утрата пред-образа.
    journal = op_dir / "journal.jsonl"
    events = []
    if journal.is_file():
        for line in journal.read_text(encoding="utf-8").splitlines():
            try:
                events.append(json.loads(line).get("event"))
            except ValueError:
                events.append("?")
    if not events or any(event not in {"start", "staged"} for event in events):
        fail("Нет backup_index.json: пред-образ утрачен, восстановление "
             "невозможно.")
    pending.unlink()
    print("Операция прервана до записи в проект: восстановление не "
          "требуется, маркер снят.")
    sys.exit(0)
try:
    index = json.loads(index_path.read_text(encoding="utf-8"))
    assert isinstance(index, dict)
    assert index.get("schema_version") == 1
    assert index.get("op_id") == op_dir.name
    backed, added, missing = index["backed"], index["added"], index["missing"]
    created_dirs = index["created_dirs"]
    removed_dirs = index["removed_dirs"]
    hashes, modes, planned = index["hashes"], index["modes"], index["planned"]
    dir_modes = index["dir_modes"]
    for value in (backed, added, missing, created_dirs, removed_dirs):
        assert isinstance(value, list)
        assert all(isinstance(rel, str) for rel in value)
        assert len(set(value)) == len(value)
    assert not set(backed) & set(added)
    assert not set(backed) & set(missing)
    assert not set(added) & set(missing)
    assert not set(created_dirs) & set(removed_dirs)
    assert isinstance(hashes, dict) and set(hashes) == set(backed)
    assert isinstance(modes, dict) and set(modes) == set(backed)
    assert all(type(mode) is int and 0 <= mode <= 0o7777
               for mode in modes.values())
    assert isinstance(dir_modes, dict) and set(dir_modes) == set(removed_dirs)
    assert all(type(mode) is int and 0 <= mode <= 0o7777
               for mode in dir_modes.values())
    assert isinstance(planned, dict)
    assert set(planned) == set(backed) | set(added) | set(missing)
    assert all(value == "absent" or (isinstance(value, str)
               and value.startswith("sha256:") and len(value) == 71)
               for value in planned.values())
    assert all(isinstance(digest_, str) and digest_.startswith("sha256:")
               and len(digest_) == 71 for digest_ in hashes.values())
except (ValueError, KeyError, AssertionError):
    fail("backup_index.json повреждён или неполон: восстановление невозможно.")
for rel in backed + added + missing + created_dirs + removed_dirs:
    candidate = Path(rel)
    resolved = (root / candidate).resolve()
    if candidate.is_absolute() or ".." in candidate.parts \
            or resolved == root or root not in resolved.parents:
        fail(f"backup_index.json содержит путь вне проекта: {rel}.")
backup_dir = op_dir / "backup"
on_disk = set()
if backup_dir.is_dir():
    for path in backup_dir.rglob("*"):
        if path.is_file():
            rel = path.relative_to(backup_dir).as_posix()
            if not any(part.startswith(".") for part in Path(rel).parts):
                on_disk.add(rel)
unlisted = sorted(on_disk - set(backed))
if unlisted:
    fail("backup_index.json неполон: копии без записи в backed: "
         + ", ".join(unlisted) + ".")
problems = []
for rel in backed:
    source = backup_dir / rel
    if not source.is_file():
        problems.append(rel + " (нет копии)")
    elif digest(source) != hashes[rel]:
        problems.append(rel + " (копия повреждена)")
if problems:
    fail("Резервная копия неполна или повреждена: " + ", ".join(problems) + ".")

# Временные файлы этой операции убираются, чтобы восстановленный состав
# совпадал с пред-образом. Принадлежность доказывается строгим шаблоном
# '.<имя>.fop-<op_id>-<8 hex>.tmp', как у engine: похожие посторонние
# файлы (без полного hex-суффикса) не трогаются.
temp_pattern = re.compile(r"\..*\.fop-" + re.escape(op_dir.name)
                          + r"-[0-9a-f]{8}\.tmp\Z")
for rel in backed + added + missing:
    parent = (root / rel).parent
    if not parent.is_dir():
        continue
    for stray in parent.iterdir():
        if not temp_pattern.match(stray.name):
            continue
        if stray.is_file() or stray.is_symlink():
            stray.unlink()

restored = removed = 0
conflicts = []
for rel in added + missing:
    target = root / rel
    current = state_of(target)
    if current == "absent":
        continue
    if rel in added and current == planned[rel]:
        target.unlink()
        removed += 1
    else:
        keep_conflict(target, rel)
        conflicts.append(rel)
        removed += 1
for rel in backed:
    target = root / rel
    current = state_of(target)
    if current != hashes[rel]:
        if current not in ("absent", planned[rel]):
            keep_conflict(target, rel)
            conflicts.append(rel)
        source = backup_dir / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    os.chmod(target, modes[rel])
    if digest(target) != digest(backup_dir / rel):
        fail(f"Восстановленный файл не совпадает с резервной копией: {rel}.")
    restored += 1
for rel in sorted(removed_dirs, key=lambda p: len(Path(p).parts)):
    target = root / rel
    if not target.is_dir():
        if target.exists() or target.is_symlink():
            keep_conflict(target, rel)
            conflicts.append(rel)
        target.mkdir(parents=True)
    os.chmod(target, dir_modes[rel])
    if target.stat().st_mode & 0o7777 != dir_modes[rel]:
        fail(f"Режим восстановленного каталога не совпадает: {rel}.")
for rel in created_dirs:
    target = root / rel
    if target.is_dir():
        try:
            target.rmdir()
        except OSError:
            conflicts.append(rel + " (каталог не пуст, оставлен)")
# Квитанция completed после отката ложно подтверждала бы применение плана:
# переводится в restored, чтобы повторный запуск плана применил его заново.
receipt = op_dir / "receipt.json"
if receipt.is_file():
    try:
        data = json.loads(receipt.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        data = None
    if isinstance(data, dict) and data.get("result") == "completed":
        data["result"] = "restored"
        receipt.write_text(json.dumps(data, ensure_ascii=False, indent=2)
                           + "\n", encoding="utf-8")
# Маркер снимается, только если он по-прежнему принадлежит этой операции.
try:
    current = json.loads(pending.read_text(encoding="utf-8"))
except (OSError, ValueError):
    current = None
removed_marker = isinstance(current, dict) \
    and current.get("op_id") == op_dir.name
if removed_marker:
    pending.unlink()
note = ""
if conflicts:
    note = (" Конфликтующее содержимое сохранено в "
            + str(op_dir / "conflicts") + ": " + ", ".join(conflicts) + ".")
if removed_marker:
    print(f"Восстановлено файлов: {restored}; удалено добавленных: {removed}; "
          f"маркер снят." + note)
else:
    print(f"Восстановлено файлов: {restored}; удалено добавленных: {removed}; "
          "маркер сменил владельца и не снят." + note, file=sys.stderr)
sys.exit(0)
