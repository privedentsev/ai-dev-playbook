# TASK-101: Исправление ошибки валидации

ID: TASK-101
Status: in_progress
Priority: P2
Depends-On: -
Executor: Codex
Model: GPT-6
Created: 2026-10-22T08:00:00+03:00
Closed: -

<!-- playbook-meta:start -->
```json
{
  "schema_version": 1,
  "relations": [],
  "materials": [
    {
      "id": "verify-ea8bdce1b3af4fa0a96d974c09579c67",
      "role": "report",
      "source": "work/verification/TASK-101/ea8bdce1b3af4fa0a96d974c09579c67",
      "storage": "local",
      "required": true,
      "immutable": true,
      "used_by": [
        "TASK-101"
      ]
    }
  ],
  "handoff": {
    "at": "2026-10-22T11:27:52+03:00",
    "actor": {
      "name": "Antigravity",
      "model": "Gemini 3.8 Flash (High)"
    },
    "summary": "первичная реализация parse_age",
    "reports": [
      "verify-ea8bdce1b3af4fa0a96d974c09579c67"
    ],
    "card_projection": "sha256:d94ca465e2205ef279b39ba2048c94458d746d5a953b108d3369c7b292f45108"
  },
  "acceptance": {
    "at": "2026-10-22T12:35:33+03:00",
    "actor": {
      "name": "Codex",
      "model": "GPT-6"
    },
    "role": "auditor",
    "kind": "diagnostic",
    "result": "accepted",
    "handoff_at": "2026-10-22T11:27:52+03:00",
    "session": null,
    "detail": "PILOT-A1: независимый аудит: пустой/пробельный ввод вызывает ValueError вместо None. Требуются исправление, regression test, verify и новая передача. Сессия 01a162f1-a308-7c12-9380-08445b6a30d0"
  }
}
```
<!-- playbook-meta:end -->

## Цель и границы
Исправление ошибки валидации в одной функции.

## Приёмка
- [x] Ошибка устранена.

## Проверки и доказательства
verify

## Выполнение и проверки
2026-10-22: исправлено.

Исправлено 2026-10-22T12:36:49+03:00; исполнитель: Codex; модель: GPT-6. PILOT-A1 — после независимого возврата реализован None для пустого и пробельного ввода; добавлены проверки пустой строки, пробелов, табуляции, перевода строки, NBSP, сохранения числового ввода и ValueError для непустых нечисловых строк. Исполнитель этой доработки: отдельный агент /root/pilot_executor; первичная версия получена от Antigravity / Gemini 3.8 Flash (High).

## Передача
Повторная передача независимому аудитору /root после PILOT-A1; самостоятельная приёмка не выполнялась.
