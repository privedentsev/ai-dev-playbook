def parse_age(value: str) -> int:
    """Парсинг возраста из строки.
    
    Исходная реализация: дефект на пустых/пробельных строках (вызывает ValueError).
    """
    return int(value)
