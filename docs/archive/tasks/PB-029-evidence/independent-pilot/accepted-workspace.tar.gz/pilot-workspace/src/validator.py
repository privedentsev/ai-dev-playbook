def parse_age(value: str) -> int | None:
    """Вернуть возраст или None для пустого и пробельного ввода."""
    cleaned = value.strip()
    if not cleaned:
        return None
    return int(cleaned)
