import unittest

class TestParser(unittest.TestCase):
    def test_parse_basic(self):
        self.assertTrue(True)

if __name__ == "__main__":
    unittest.main()
