import unittest
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.validator import parse_age

class TestValidator(unittest.TestCase):
    def test_valid_age(self):
        self.assertEqual(parse_age("25"), 25)

    def test_whitespace_age(self):
        self.assertEqual(parse_age(" 42 "), 42)

    def test_empty_and_whitespace_return_none(self):
        for value in ("", " ", "   ", "\t", "\n", " \t\n ", "\u00a0"):
            with self.subTest(value=value):
                self.assertIsNone(parse_age(value))

    def test_numeric_values_are_preserved(self):
        for value, expected in (("0", 0), (" 17\n", 17), ("+25", 25)):
            with self.subTest(value=value):
                self.assertEqual(parse_age(value), expected)

    def test_invalid_nonempty_value_still_raises(self):
        for value in ("abc", "2.5"):
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    parse_age(value)

if __name__ == "__main__":
    unittest.main()
