"""Проверяемые lifecycle-операции документов и карточек: plan/apply/restore.

PB-025 реализует ``archive_document``; PB-026 добавляет действия карточек
``close_task``/``reopen`` и ``promote_change`` документов, а также записи
передачи (handoff) и приёмки (acceptance) — границу независимой приёмки.
Все действия применяются одной операцией через общий engine
file_operations (design §6–7, ADR-0002).

Request — JSON-файл в проекте::

    {"schema_version": 1,
     "actor": {"name": str, "role": str, "model": str|null,
               "session": str|null},
     "basis": "основание операции",
     "scope": {"documents": ["kind:slug", ...], "tasks": ["ID", ...]},
     "actions": [
       {"action": "archive_document", "document": "kind:slug",
        "reason": str, "successor": "kind:slug"|null,
        "confirmed_materials": [id, ...]},
       {"action": "close_task", "task": "ID", "outcome": "done|cancelled",
        "reason": str (обязательна для cancelled),
        "acceptance": str|null, "confirmed_materials": [id, ...]},
       {"action": "reopen", "task": "ID",
        "status": "draft|ready|in_progress|blocked", "reason": str},
       {"action": "promote_change", "document": "kind:slug",
        "change": "chg-id", "payload": "текст новой редакции",
        "acceptance": str|null}]}

``scope`` обязан совпадать с целями ``actions``: документные действия
закрывают ``scope.documents``, карточные — ``scope.tasks``.
``confirmed_materials`` фиксирует подтверждённую доступность обязательных
внешних материалов: неподтверждённый required external блокирует операцию.
CLI проверяет структуру, область и состояние файлов — содержательную
правильность основания и причины подтверждает исполнитель.

``close_task`` переносит карточку и её доказательства в архив. Для
legacy-карточки (без блока метаданных) действует прежняя политика:
``docs/tasks/<ID>-evidence/`` и ``work/verification/<ID>/`` переносятся
целиком. Для карточки с метаданными переход в ``done`` требует записи
``handoff`` (передача: исполнитель, модель, отчёты verify, отпечаток
проекции карточки) и записи ``acceptance`` (независимая приёмка,
привязанная к передаче полем ``handoff_at``); устаревшие входы отчётов и
изменение карточки после передачи отклоняют операцию. ``cancelled``
требует записи приёмки с ``result=cancelled``.

``reopen`` возвращает архивную карточку в работу (``ready``,
``in_progress``, ``draft`` либо ``blocked``), сбрасывает записи
передачи/приёмки в метаданных (история остаётся в архивных материалах и
сопровождающих JSON) и переводит в ``blocked`` активных зависимых. Операция отклоняется, если
после неё граф статусов недопустим (например, done-зависимый при
возвращённой зависимости).

``promote_change`` принимает изменение с state=implemented: тело
документа заменяется payload'ом, прежняя редакция сохраняется как
неизменяемый материал ``<stem>-evidence/revision-N.md``, изменение
получает state=accepted, current_revision увеличивается.

``lifecycle plan request.json [--save]`` строит детерминированный план:
карту переносов, байты всех записей (новые тексты с обновлёнными
метаданными и ссылками, переписанные затронутые файлы, индексы,
сопровождающие JSON) и снимок входов. ``--save`` пишет план в
``work/lifecycle/plans/<plan_id>.json``; в плане — только хеши.

``lifecycle apply <plan.json>`` пересобирает план из сохранённого запроса и
текущего дерева и обязан получить идентичные plan_id, входы и хеши записей:
изменившиеся входы или подмена сохранённого JSON отклоняются до записи.
Затем план применяется file_operations.run_operation — staged-копия,
резервные копии, журнал, итоговые проверки (каталог, индексы затронутых
коллекций и задач, ссылки всего дерева) и квитанция. Повторный apply
завершённого plan_id сообщает already_completed и не создаёт второй
перенос.

``lifecycle status`` показывает маркер незавершённой операции и сохранённые
планы; ``lifecycle restore`` восстанавливает дерево по backup_index через
file_operations.restore_operation. Записи передачи и приёмки создают
отдельные команды playbook.py ``lifecycle handoff``/``accept``.
"""

import datetime as dt
import difflib
import json
import os
import re
import unicodedata
from pathlib import Path, PurePosixPath

import document_links
import documents
import file_operations
import verification

PLAN_SCHEMA = 1
PLANS_DIR = file_operations.WORK_DIR + "/plans"

# Обязательные и допустимые поля каждого действия (кроме "action").
ACTION_SPECS = {
    "archive_document": ({"document", "reason"},
                         {"document", "reason", "successor",
                          "confirmed_materials"}),
    "close_task": ({"task", "outcome"},
                   {"task", "outcome", "reason", "acceptance",
                    "confirmed_materials"}),
    "reopen": ({"task", "status", "reason"},
               {"task", "status", "reason"}),
    "promote_change": ({"document", "change", "payload"},
                       {"document", "change", "payload", "acceptance"}),
}
ACTIONS = frozenset(ACTION_SPECS)
DOCUMENT_ACTIONS = {"archive_document", "promote_change"}
TASK_ACTIONS = {"close_task", "reopen"}

REQUEST_FIELDS = {"schema_version", "actor", "basis", "scope", "actions"}
ACTOR_FIELDS = {"name", "model", "role", "session"}
SCOPE_FIELDS = {"documents", "tasks"}
CLOSE_OUTCOMES = {"done", "cancelled"}
# ready/in_progress — прямой возврат в работу; draft/blocked — для
# зависимых, чьи зависимости возвращены этой же операцией.
REOPEN_STATES = {"draft", "ready", "in_progress", "blocked"}

# Внутри work/ переносимы только зарегистрированные результаты проверок и
# сохранённые запросы/планы; живое состояние операций и обновлений
# материалом не является и не переносится.
MOVABLE_WORK = ("work/verification/", "work/lifecycle/plans/")
FINAL_TASK_STATES = {"done", "cancelled"}
# Зависимые возвращённой карточки с этими статусами переводятся в blocked.
BLOCKABLE_STATES = {"ready", "in_progress", "in_review"}

# Разделы карточки-протокола: их дописывание (записи выполнения, передачи,
# аудита и исправлений) не меняет проверяемую проекцию карточки.
PROTOCOL_SECTIONS = ("Выполнение и проверки", "Передача")
PROTOCOL_PREFIXES = ("Аудит", "Повторный аудит", "Исправлено")


def _rel(root, path):
    return path.relative_to(root).as_posix()


def _unknown_fields(data, allowed, label, require):
    unknown = sorted(set(data) - allowed)
    require(not unknown, f"{label}: неизвестные поля {unknown}")


def _canonical(data):
    return json.dumps(data, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"))


def _required_str(action, field, label, require):
    value = action.get(field)
    require(isinstance(value, str) and value.strip(),
            f"{label}.{field}: непустая строка")
    return value.strip()


def _optional_str(action, field, label, require):
    value = action.get(field)
    require(value is None or (isinstance(value, str) and value.strip()),
            f"{label}.{field}: непустая строка либо отсутствует")
    return value.strip() if isinstance(value, str) else None


def _confirmed_materials(action, label, require):
    confirmed = action.get("confirmed_materials") or []
    require(isinstance(confirmed, list)
            and all(isinstance(item, str) for item in confirmed),
            f"{label}.confirmed_materials: список id материалов")
    return sorted(set(confirmed))


def _normalize_action(kind, action, label, require):
    """Проверка полей действия → нормализованный объект."""
    item = {"action": kind}
    if kind in DOCUMENT_ACTIONS:
        doc_id = action.get("document")
        require(isinstance(doc_id, str)
                and documents.DOC_ID.fullmatch(doc_id),
                f"{label}.document: ID 'kind:slug'")
        item["document"] = doc_id
    else:
        task = action.get("task")
        require(isinstance(task, str) and documents.TASK_ID.fullmatch(task),
                f"{label}.task: ID карточки")
        item["task"] = task
    if kind == "archive_document":
        item["reason"] = _required_str(action, "reason", label, require)
        successor = action.get("successor")
        require(successor is None
                or (isinstance(successor, str)
                    and documents.DOC_ID.fullmatch(successor)),
                f"{label}.successor: ID документа либо null")
        item["successor"] = successor
        item["confirmed_materials"] = _confirmed_materials(action, label,
                                                         require)
    elif kind == "close_task":
        outcome = action.get("outcome")
        require(outcome in CLOSE_OUTCOMES,
                f"{label}.outcome: {'|'.join(sorted(CLOSE_OUTCOMES))}")
        item["outcome"] = outcome
        # Отмена без записанной причины лишает историю объяснения.
        if outcome == "cancelled":
            item["reason"] = _required_str(action, "reason", label, require)
        else:
            item["reason"] = _optional_str(action, "reason", label, require)
        item["acceptance"] = _optional_str(action, "acceptance", label,
                                           require)
        item["confirmed_materials"] = _confirmed_materials(action, label,
                                                         require)
    elif kind == "reopen":
        status = action.get("status")
        require(status in REOPEN_STATES,
                f"{label}.status: {'|'.join(sorted(REOPEN_STATES))}")
        item["status"] = status
        item["reason"] = _required_str(action, "reason", label, require)
    else:  # promote_change
        item["change"] = _required_str(action, "change", label, require)
        item["payload"] = _required_str(action, "payload", label, require)
        item["acceptance"] = _optional_str(action, "acceptance", label,
                                           require)
    return item


def validate_request(data, require):
    """Нормализованный запрос lifecycle-операции из JSON-объекта."""
    require(isinstance(data, dict), "Запрос должен быть JSON-объектом")
    _unknown_fields(data, REQUEST_FIELDS, "request", require)
    require(data.get("schema_version") == 1,
            f"request.schema_version {data.get('schema_version')!r} "
            "не поддерживается")
    actor = data.get("actor")
    require(isinstance(actor, dict), "request.actor: ожидается объект")
    _unknown_fields(actor, ACTOR_FIELDS, "request.actor", require)
    for field in ("name", "role"):
        require(isinstance(actor.get(field), str) and actor[field].strip(),
                f"request.actor.{field}: непустая строка")
    for field in ("model", "session"):
        require(actor.get(field) is None or isinstance(actor.get(field), str),
                f"request.actor.{field}: строка либо null")
    require(isinstance(data.get("basis"), str) and data["basis"].strip(),
            "request.basis: непустая строка основания")
    scope = data.get("scope")
    require(isinstance(scope, dict), "request.scope: ожидается объект")
    _unknown_fields(scope, SCOPE_FIELDS, "request.scope", require)
    expected = {}
    for key in sorted(set(scope) & SCOPE_FIELDS):
        values = scope[key]
        pattern = documents.DOC_ID if key == "documents" else documents.TASK_ID
        shape = "ID 'kind:slug'" if key == "documents" else "ID карточки"
        require(isinstance(values, list) and values
                and all(isinstance(item, str) and pattern.fullmatch(item)
                        for item in values),
                f"request.scope.{key}: непустой список {shape}")
        require(len(set(values)) == len(values),
                f"request.scope.{key}: повторные ID")
        expected[key] = set(values)
    require(expected, "request.scope: нужен список documents и/или tasks")
    actions = data.get("actions")
    require(isinstance(actions, list) and actions,
            "request.actions: непустой список")
    normalized = []
    targets = {"documents": set(), "tasks": set()}
    for index, action in enumerate(actions):
        label = f"request.actions[{index}]"
        require(isinstance(action, dict), f"{label}: ожидается объект")
        kind = action.get("action")
        require(kind in ACTIONS, f"{label}: неизвестное действие {kind!r}")
        required, allowed = ACTION_SPECS[kind]
        _unknown_fields(action, allowed | {"action"}, label, require)
        missing = sorted(field for field in required
                         if action.get(field) is None)
        require(not missing, f"{label}: нет обязательных полей {missing}")
        item = _normalize_action(kind, action, label, require)
        bucket = "documents" if kind in DOCUMENT_ACTIONS else "tasks"
        target = item.get("document") or item["task"]
        require(target not in targets[bucket],
                f"{label}: повторное действие для {target}")
        targets[bucket].add(target)
        normalized.append(item)
    for key in ("documents", "tasks"):
        wanted, got = expected.get(key, set()), targets[key]
        require(wanted == got,
                f"request.scope.{key} не совпадает с actions: "
                f"без действия {sorted(wanted - got)}, "
                f"вне scope {sorted(got - wanted)}")
    return {"schema_version": 1,
            "actor": {key: actor.get(key)
                      for key in sorted(ACTOR_FIELDS & set(actor))},
            "basis": data["basis"].strip(),
            "scope": {key: sorted(values) for key, values in expected.items()},
            "actions": normalized}


def _movable_material(rel, material, doc_id, require):
    """Служебные области work/ не переносятся как материалы."""
    if rel.startswith("work/"):
        require(any(rel.startswith(item) for item in MOVABLE_WORK),
                f"{doc_id}: материал '{material.get('id')}' ({rel}) — "
                "служебная область work/; переносимы только "
                "work/verification/<id>/ и work/lifecycle/plans/")


def _protected_files(paths, records, catalog):
    """Индексы, карточки и документы — материал не накрывает их."""
    protected = {paths["task_index"].resolve()}
    protected.update(rec["path"].resolve() for rec in records.values())
    if catalog is not None:
        protected.update(entry["index"].resolve()
                         for entry in catalog["collections"].values())
        protected.update(item["path"].resolve()
                         for item in catalog["documents"].values())
    return protected


def _free_name(directory, target, root, require):
    """Отказ при коллизии имени назначения (NFC + casefold)."""
    if directory.is_dir():
        folded = unicodedata.normalize("NFC", target.name).casefold()
        for child in directory.iterdir():
            require(unicodedata.normalize("NFC", child.name).casefold()
                    != folded, f"Коллизия имени: {_rel(root, child)}")


def _move_materials(root, owner, materials, self_path, home_dir, dest_dir,
                    evidence_dir, protected, confirmed, safe_path, require):
    """Карта переносов локальных материалов владельца.

    Материал внутри home_dir сохраняет путь относительно dest_dir;
    материал вне home_dir уходит в evidence_dir с полным относительным
    путём от корня. Назначение обязано оставаться внутри dest_dir.
    """
    moves, dir_moves, file_moves = {}, {}, {}
    top_moves, moved, external = [], [], []
    for material in materials:
        if material.get("storage") != "local":
            external.append({"id": material.get("id"),
                             "source": material.get("source"),
                             "required": bool(material.get("required")),
                             "confirmed": material.get("id") in confirmed})
            continue
        src = material.get("resolved")
        require(src is not None and src.exists(),
                f"{owner}: материал '{material.get('id')}' отсутствует: "
                f"{material.get('source')}")
        rel_src = _rel(root, src)
        _movable_material(rel_src, material, owner, require)
        resolved_src = src.resolve()
        require(resolved_src != self_path.resolve()
                and not self_path.resolve().is_relative_to(resolved_src),
                f"{owner}: материал '{material.get('id')}' накрывает "
                "самого владельца")
        if resolved_src.is_dir():
            for path in sorted(protected):
                require(not path.is_relative_to(resolved_src),
                        f"{owner}: материал '{material.get('id')}' "
                        f"({rel_src}) накрывает служебный файл {path}")
        if resolved_src.is_relative_to(home_dir.resolve()):
            dst = dest_dir / resolved_src.relative_to(home_dir.resolve())
        else:
            dst = evidence_dir / resolved_src.relative_to(root.resolve())
        resolved_dst = dst.resolve()
        require(resolved_dst.is_relative_to(dest_dir.resolve()),
                f"{owner}: назначение материала '{material.get('id')}' "
                f"вне области назначения: {_rel(root, dst)}")
        require(not dst.exists() and not dst.is_symlink(),
                f"Назначение занято: {_rel(root, dst)}")
        moves[resolved_src] = resolved_dst
        top_moves.append((resolved_src, resolved_dst))
        if resolved_src.is_dir():
            for sub in sorted(resolved_src.rglob("*")):
                mapped = resolved_dst / sub.relative_to(resolved_src)
                if sub.is_dir():
                    dir_moves[sub] = mapped
                else:
                    moves[sub] = file_moves[sub] = mapped
            dir_moves[resolved_src] = resolved_dst
        else:
            file_moves[resolved_src] = resolved_dst
        moved.append({"id": material.get("id"), "role": material.get("role"),
                      "storage": "local", "source_old": rel_src,
                      "source_new": resolved_dst.relative_to(root)
                      .as_posix(),
                      "required": bool(material.get("required")),
                      "immutable": bool(material.get("immutable")),
                      "used_by": list(material.get("used_by") or [])})
    return {"moves": moves, "dir_moves": dir_moves, "file_moves": file_moves,
            "top_moves": top_moves, "materials": moved, "external": external}


def _plan_archive(root, catalog, paths, action, at, safe_path, require):
    """Перенос документа и материалов → запись плана действия."""
    doc_id = action["document"]
    entry = catalog["documents"].get(doc_id)
    require(entry is not None,
            f"{doc_id}: нет зарегистрированного документа — legacy сначала "
            "регистрируется командой document register")
    require(not entry["archived"], f"{doc_id}: документ уже в архиве")
    kind = entry["kind"]
    require(entry["state"] in documents.ARCHIVED_STATES,
            f"{doc_id}: состояние '{entry['state']}' не финальное — "
            "архивирование требует одно из "
            f"{sorted(documents.ARCHIVED_STATES & documents.STATES[kind])}")
    successor = action["successor"]
    if successor is not None:
        require(successor != doc_id, f"{doc_id}: преемник совпадает с документом")
        require(successor in catalog["documents"],
                f"{doc_id}: successor '{successor}' — нет такого документа")
    if kind == "plan":
        open_tasks = [task for task in entry["tasks"]
                      if task in catalog["records"]
                      and catalog["records"][task]["status"]
                      not in FINAL_TASK_STATES]
        require(not open_tasks,
                f"{doc_id}: план с незавершёнными задачами {open_tasks} — "
                "завершите или отмените их до архивирования")
    cols = catalog["collections"][kind]
    old_path = entry["path"]
    new_path = cols["archive"] / old_path.name
    require(not new_path.exists() and not new_path.is_symlink(),
            f"Назначение занято: {_rel(root, new_path)}")
    if cols["archive"].is_dir():
        folded = unicodedata.normalize("NFC", new_path.name).casefold()
        for child in cols["archive"].iterdir():
            require(unicodedata.normalize("NFC", child.name).casefold()
                    != folded,
                    f"Коллизия имени в архиве: {_rel(root, child)}")
    stray = [item["path"] for item in catalog["candidates"]
             if item.get("owner") == doc_id]
    require(not stray,
            f"{doc_id}: неучтённые материалы {sorted(stray)} — зарегистрируйте "
            "их в materials либо уберите перед архивированием")
    confirmed = set(action["confirmed_materials"])
    material_ids = {item.get("id") for item in entry["materials"]
                    if isinstance(item.get("id"), str)}
    extra = sorted(confirmed - material_ids)
    require(not extra, f"{doc_id}: confirmed_materials — неизвестные id {extra}")
    unconfirmed = sorted(
        item["id"] for item in entry["materials"]
        if item.get("storage") == "external" and item.get("required")
        and isinstance(item.get("id"), str) and item["id"] not in confirmed)
    require(not unconfirmed,
            f"{doc_id}: обязательные внешние материалы без подтверждения "
            f"доступа {unconfirmed} — перечислите их в confirmed_materials")
    evidence_dir = new_path.parent / f"{new_path.stem}-evidence"
    protected = _protected_files(paths, catalog["records"], catalog)
    shift = _move_materials(root, doc_id, entry["materials"], old_path,
                            old_path.parent, cols["archive"], evidence_dir,
                            protected, confirmed, safe_path, require)
    moves = shift["moves"]
    dir_moves, file_moves = shift["dir_moves"], shift["file_moves"]
    top_moves, materials, external = (shift["top_moves"], shift["materials"],
                                      shift["external"])
    moves[old_path.resolve()] = new_path.resolve()
    file_moves[old_path.resolve()] = new_path.resolve()
    top_moves.append((old_path.resolve(), new_path.resolve()))
    return {"atype": "archive_document", "document": doc_id, "kind": kind,
            "entry": entry, "reason": action["reason"],
            "successor": successor,
            "old_path": old_path, "new_path": new_path,
            "evidence_dir": evidence_dir, "moves": moves,
            "dir_moves": dir_moves, "file_moves": file_moves,
            "top_moves": top_moves,
            "materials": materials, "external": external, "blocked": []}


def card_projection(text):
    """SHA-256 проекции значимого содержимого карточки.

    В отпечаток входят заголовок, поля шапки (кроме Status/Closed — их
    меняют сами переходы) и разделы требований. Исключаются блок
    метаданных и журнальные разделы (Выполнение и проверки, Передача,
    Аудит/Повторный аудит/Исправлено): дописывание протокола не
    обесценивает переданную реализацию, а правка цели, зависимостей,
    приёмки или списка проверок делает передачу несвежей.
    """
    lines = text.split("\n")
    positions = documents._meta_positions(lines)
    if isinstance(positions, tuple):
        start, end = positions
        lines = lines[:start] + lines[end + 1:]
    kept, fence, skip = [], None, False
    for line in lines:
        if fence is not None:
            if document_links.closes_fence(line, fence):
                fence = None
            if not skip:
                kept.append(line)
            continue
        marker = document_links.FENCE.match(line)
        if marker:
            fence = marker.group(1)
            if not skip:
                kept.append(line)
            continue
        heading = re.match(r"^ {0,3}##\s+(.+?)\s*$", line)
        if heading:
            title = heading.group(1)
            skip = title in PROTOCOL_SECTIONS or any(
                title.startswith(prefix) for prefix in PROTOCOL_PREFIXES)
            if not skip:
                kept.append(line)
            continue
        if skip:
            continue
        if re.match(r"^(Status|Closed):", line):
            continue
        kept.append(line)
    return file_operations.sha256("\n".join(kept).encode("utf-8"))


def _task_meta(path, rel, require):
    """(text, meta) карточки; meta=None для legacy-карточки."""
    text = path.read_text(encoding="utf-8")
    errors = []
    meta = documents.parse_meta(text, rel, errors)
    require(not errors, "; ".join(errors))
    return text, meta


def _task_meta_entry(catalog, task_id, meta, require):
    """Карточка с блоком метаданных требует каталог и запись task_meta."""
    if meta is None:
        return None
    require(catalog is not None and task_id in catalog["task_meta"],
            f"{task_id}: карточка с метаданными требует раздел documents "
            "project.json — в каталоге её запись отсутствует")
    return catalog["task_meta"][task_id]


def _close_text(text, outcome, stamp, task_id, require):
    """Текст закрываемой карточки: статус и Closed."""
    new_text, count = re.subn(r"(?m)^Status: [^\n]+$", f"Status: {outcome}",
                              text, count=1)
    require(count == 1, f"{task_id}: не найдена строка Status")
    new_text, count = re.subn(r"(?m)^Closed: -$", f"Closed: {stamp}",
                              new_text, count=1)
    require(count == 1, f"{task_id}: не найдена строка Closed")
    return new_text


def _reopen_text(text, rec, status, reason, stamp, actor, require):
    """Текст возвращаемой карточки: статус, сброс Closed, запись возврата."""
    new_text, count = re.subn(r"(?m)^Status: [^\n]+$", f"Status: {status}",
                              text, count=1)
    require(count == 1, f"{rec['id']}: не найдена строка Status")
    new_text, count = re.subn(r"(?m)^Closed: [^\n]+$", "Closed: -",
                              new_text, count=1)
    require(count == 1, f"{rec['id']}: не найдена строка Closed")
    if not new_text.endswith("\n"):
        new_text += "\n"
    new_text += (f"\n## Возврат {stamp}; исполнитель: "
                 f"{_actor_label(actor)}. Причина: {reason}. "
                 f"Прежний исход: {rec['status']} "
                 f"(Closed {rec['closed']}). История закрытия и приёмки "
                 "сохранена в материалах карточки и неизменна.\n")
    return new_text


def _blocked_text(text, dep_id, source_id, stamp, actor, require):
    """Зависимая карточка при возврате зависимости: статус blocked + запись."""
    new_text, count = re.subn(r"(?m)^Status: [^\n]+$", "Status: blocked",
                              text, count=1)
    require(count == 1, f"{dep_id}: не найдена строка Status")
    if not new_text.endswith("\n"):
        new_text += "\n"
    new_text += (f"\n## Блокировка {stamp}; исполнитель: "
                 f"{_actor_label(actor)}. Зависимость {source_id} "
                 "возвращена в работу — карточка переведена в blocked "
                 "до повторной готовности.\n")
    return new_text


def _close_evidence(root, task_id, rec, text, outcome, task_meta,
                    safe_path, require):
    """Граница приёмки карточки с метаданными.

    done требует записи передачи со свежей проекцией карточки, свежего
    успешного прогона verify (если прогоны зарегистрированы) и записи
    приёмки, привязанной к этой передаче. cancelled требует записи
    приёмки с result=cancelled. Diagnostic-протокол принимает только
    карточка аудита без зависимостей — у остальных он приёмкой не
    является.
    """
    rel = _rel(root, rec["path"])
    handoff = task_meta.get("handoff")
    acceptance = task_meta.get("acceptance")
    if outcome == "cancelled":
        require(isinstance(acceptance, dict)
                and acceptance.get("result") == "cancelled",
                f"{task_id}: отмена карточки с метаданными требует записи "
                "приёмки с result=cancelled — выполните lifecycle accept "
                "--result cancelled")
        return
    require(isinstance(handoff, dict),
            f"{task_id}: нет записи передачи на приёмку — выполните "
            "lifecycle handoff после последних изменений")
    require(card_projection(text) == handoff.get("card_projection"),
            f"{task_id}: карточка изменилась после передачи (цель, "
            "зависимости или критерии приёмки) — повторите затронутую "
            "проверку и lifecycle handoff")
    materials = {item.get("id"): item for item in task_meta["materials"]}
    fresh = []
    for ref in handoff.get("reports") or []:
        material = materials.get(ref)
        require(material is not None,
                f"{task_id}: отчёт '{ref}' не зарегистрирован в materials")
        require(material.get("storage") == "local",
                f"{task_id}: отчёт '{ref}' — внешний материал, свежесть "
                "входов не проверяется")
        src = material.get("resolved")
        require(src is not None and src.exists(),
                f"{task_id}: отчёт '{ref}' отсутствует: "
                f"{material.get('source')}")
        report_path = src / "report.json" if src.is_dir() else src
        report = verification.load_report(report_path, require)
        require(report.get("task_id") == task_id,
                f"{task_id}: отчёт '{ref}' принадлежит задаче "
                f"{report.get('task_id')}")
        if report.get("status") == "passed" \
                and report.get("inputs_unchanged"):
            ok, _ = verification.inputs_fresh(root, report, {rel},
                                              safe_path, require)
            if ok:
                fresh.append(ref)
    require(not handoff.get("reports") or fresh,
            f"{task_id}: нет свежего успешного прогона verify — входы "
            "изменились после проверки; повторите verify и handoff")
    require(isinstance(acceptance, dict),
            f"{task_id}: нет записи приёмки — выполните lifecycle accept")
    require(acceptance.get("result") == "accepted",
            f"{task_id}: приёмка не подтверждена "
            f"(result={acceptance.get('result')!r})")
    require(acceptance.get("handoff_at") == handoff.get("at"),
            f"{task_id}: приёмка привязана к прежней передаче — повторите "
            "lifecycle accept после handoff")
    if not (task_id.startswith("AUDIT") and not rec["deps"]):
        require(acceptance.get("kind") == "acceptance",
                f"{task_id}: diagnostic-протокол не является приёмкой — "
                "нужна запись kind=acceptance")


def _legacy_task_moves(root, paths, task_id, evidence_dir, moves,
                       dir_moves, file_moves, top_moves, safe_path, require,
                       home=None, dest=None):
    """Legacy-карточка: деревья evidence и прогонов verify переносятся
    целиком, с сохранением внутренней структуры.

    close: home=docs/tasks → dest=docs/archive/tasks; прогоны уходят в
    evidence_dir с полным относительным путём. reopen — наоборот.
    """
    home = home or paths["tasks"]
    dest = dest or paths["archive"]
    if dest == paths["archive"]:
        sources = [home / f"{task_id}-evidence",
                   safe_path(root, f"work/verification/{task_id}")]
    else:
        sources = [home / f"{task_id}-evidence"]
    for src in sources:
        if not src.exists() and not src.is_symlink():
            continue
        require(src.is_dir() and not src.is_symlink(),
                f"{task_id}: материалы не являются каталогом: "
                f"{_rel(root, src)}")
        resolved_src = src.resolve()
        for link in documents._walk_links(resolved_src):
            require(False, f"{task_id}: символическая ссылка в материалах: "
                    f"{link.relative_to(root)}")
        if resolved_src.is_relative_to(home.resolve()):
            dst = dest / resolved_src.relative_to(home.resolve())
        else:
            dst = evidence_dir / resolved_src.relative_to(root.resolve())
        resolved_dst = dst.resolve()
        require(resolved_dst.is_relative_to(dest.resolve()),
                f"{task_id}: назначение материалов вне области "
                f"назначения: {_rel(root, dst)}")
        require(not resolved_dst.exists()
                and not resolved_dst.is_symlink(),
                f"Назначение занято: {_rel(root, dst)}")
        moves[resolved_src] = resolved_dst
        top_moves.append((resolved_src, resolved_dst))
        for sub in sorted(resolved_src.rglob("*")):
            mapped = resolved_dst / sub.relative_to(resolved_src)
            if sub.is_dir():
                dir_moves[sub] = mapped
            else:
                moves[sub] = file_moves[sub] = mapped
        dir_moves[resolved_src] = resolved_dst


def _plan_close(root, catalog, paths, records, action, at, ctx,
                safe_path, require):
    """Закрытие карточки: карточка и доказательства → архив."""
    task_id = action["task"]
    rec = records.get(task_id)
    require(rec is not None, f"Нет задачи: {task_id}")
    require(not rec["archived"], f"{task_id}: карточка уже в архиве")
    outcome = action["outcome"]
    require(rec["status"] not in FINAL_TASK_STATES,
            f"{task_id}: уже {rec['status']} — перенесите в архив вручную")
    if outcome == "done":
        require(rec["status"] == "in_review",
                f"{task_id}: done только из in_review (после аудита), "
                f"сейчас {rec['status']}")
    old_path = rec["path"]
    new_path = paths["archive"] / old_path.name
    require(not new_path.exists() and not new_path.is_symlink(),
            f"В архиве уже есть карточка: {new_path.name}")
    _free_name(paths["archive"], new_path, root, require)
    stamp_dt = dt.datetime.fromisoformat(at)
    require(rec["created_ts"] is None or stamp_dt >= rec["created_ts"],
            f"{task_id}: Closed раньше Created")
    rel = _rel(root, old_path)
    text, meta = _task_meta(old_path, rel, require)
    task_meta = _task_meta_entry(catalog, task_id, meta, require)
    if outcome == "done":
        lines = ctx["unconfirmed"](text)
        require(not lines,
                f"{task_id}: модель не подтверждена — маркер "
                f"'{ctx['model_unconfirmed']}' в карточке (строки "
                f"{', '.join(map(str, lines))}). Инженер вписывает точное "
                "название или 'неизвестна' вместо маркера, затем повторяет "
                "close")
    evidence_dir = new_path.parent / f"{task_id}-evidence"
    moves, dir_moves, file_moves = {}, {}, {}
    top_moves, materials, external = [], [], []
    if task_meta is not None:
        _close_evidence(root, task_id, rec, text, outcome, task_meta,
                        safe_path, require)
        confirmed = set(action.get("confirmed_materials") or [])
        material_ids = {item.get("id") for item in task_meta["materials"]
                        if isinstance(item.get("id"), str)}
        extra = sorted(confirmed - material_ids)
        require(not extra,
                f"{task_id}: confirmed_materials — неизвестные id {extra}")
        unconfirmed_ext = sorted(
            item["id"] for item in task_meta["materials"]
            if item.get("storage") == "external" and item.get("required")
            and isinstance(item.get("id"), str)
            and item["id"] not in confirmed)
        require(not unconfirmed_ext,
                f"{task_id}: обязательные внешние материалы без "
                f"подтверждения доступа {unconfirmed_ext} — перечислите их "
                "в confirmed_materials")
        stray = [item["path"] for item in catalog["candidates"]
                 if item.get("owner") == task_id]
        require(not stray,
                f"{task_id}: неучтённые материалы {sorted(stray)} — "
                "зарегистрируйте их в materials либо уберите перед "
                "закрытием (lifecycle handoff регистрирует прогоны verify)")
        protected = _protected_files(paths, records, catalog)
        shift = _move_materials(root, task_id, task_meta["materials"],
                                old_path, paths["tasks"], paths["archive"],
                                evidence_dir, protected, confirmed,
                                safe_path, require)
        moves, dir_moves, file_moves = (shift["moves"], shift["dir_moves"],
                                        shift["file_moves"])
        top_moves = shift["top_moves"]
        materials, external = shift["materials"], shift["external"]
    else:
        _legacy_task_moves(root, paths, task_id, evidence_dir, moves,
                           dir_moves, file_moves, top_moves, safe_path,
                           require)
    moves[old_path.resolve()] = new_path.resolve()
    file_moves[old_path.resolve()] = new_path.resolve()
    top_moves.append((old_path.resolve(), new_path.resolve()))
    return {"atype": "close_task", "task": task_id, "record": rec,
            "outcome": outcome, "reason": action.get("reason"),
            "acceptance": action.get("acceptance"), "meta": meta,
            "task_meta": task_meta,
            "old_path": old_path, "new_path": new_path,
            "evidence_dir": evidence_dir, "moves": moves,
            "dir_moves": dir_moves, "file_moves": file_moves,
            "top_moves": top_moves,
            "materials": materials, "external": external,
            "blocked": []}


def _plan_reopen(root, catalog, paths, records, action, at, ctx,
                 safe_path, require):
    """Возврат архивной карточки в работу; история остаётся в материалах."""
    task_id = action["task"]
    rec = records.get(task_id)
    require(rec is not None, f"Нет задачи: {task_id}")
    require(rec["archived"],
            f"{task_id}: карточка не в архиве — возврат применим "
            "к закрытым")
    old_path = rec["path"]
    new_path = paths["tasks"] / old_path.name
    require(not new_path.exists() and not new_path.is_symlink(),
            f"Назначение занято: {_rel(root, new_path)}")
    _free_name(paths["tasks"], new_path, root, require)
    rel = _rel(root, old_path)
    _, meta = _task_meta(old_path, rel, require)
    task_meta = _task_meta_entry(catalog, task_id, meta, require)
    evidence_dir = new_path.parent / f"{task_id}-evidence"
    moves, dir_moves, file_moves = {}, {}, {}
    top_moves, materials, external = [], [], []
    if task_meta is not None:
        stray = [item["path"] for item in catalog["candidates"]
                 if item.get("owner") == task_id]
        require(not stray,
                f"{task_id}: неучтённые материалы {sorted(stray)} — "
                "зарегистрируйте их в materials либо уберите перед возвратом")
        protected = _protected_files(paths, records, catalog)
        shift = _move_materials(root, task_id, task_meta["materials"],
                                old_path, paths["archive"], paths["tasks"],
                                evidence_dir, protected, set(),
                                safe_path, require)
        moves, dir_moves, file_moves = (shift["moves"], shift["dir_moves"],
                                        shift["file_moves"])
        top_moves = shift["top_moves"]
        materials, external = shift["materials"], shift["external"]
    else:
        _legacy_task_moves(root, paths, task_id, evidence_dir, moves,
                           dir_moves, file_moves, top_moves, safe_path,
                           require, home=paths["archive"],
                           dest=paths["tasks"])
    moves[old_path.resolve()] = new_path.resolve()
    file_moves[old_path.resolve()] = new_path.resolve()
    top_moves.append((old_path.resolve(), new_path.resolve()))
    return {"atype": "reopen", "task": task_id, "record": rec,
            "status": action["status"], "reason": action["reason"],
            "meta": meta, "task_meta": task_meta,
            "old_path": old_path, "new_path": new_path,
            "evidence_dir": evidence_dir, "moves": moves,
            "dir_moves": dir_moves, "file_moves": file_moves,
            "top_moves": top_moves,
            "materials": materials, "external": external,
            "blocked": []}


def _plan_promote(root, catalog, paths, action, at, safe_path, require):
    """Promotion принятого изменения: новая ревизия требований."""
    doc_id = action["document"]
    entry = catalog["documents"].get(doc_id)
    require(entry is not None,
            f"{doc_id}: нет зарегистрированного документа — legacy сначала "
            "регистрируется командой document register")
    require(not entry["archived"],
            f"{doc_id}: документ в архиве — promotion невозможен")
    change_id = action["change"]
    change = next((item for item in entry["changes"]
                   if item.get("id") == change_id), None)
    require(change is not None,
            f"{doc_id}: нет изменения '{change_id}' в метаданных")
    require(change.get("state") == "implemented",
            f"{doc_id}: изменение '{change_id}' в состоянии "
            f"'{change.get('state')}' — promotion требует implemented")
    old_path = entry["path"]
    rel = _rel(root, old_path)
    errors = []
    meta = documents.parse_meta(old_path.read_text(encoding="utf-8"),
                                rel, errors)
    require(not errors and meta is not None,
            f"{rel}: метаданные не разбираются")
    evidence_dir = old_path.parent / f"{old_path.stem}-evidence"
    stray = [item["path"] for item in catalog["candidates"]
             if item.get("owner") == doc_id]
    require(not stray,
            f"{doc_id}: неучтённые материалы {sorted(stray)} — "
            "зарегистрируйте их в materials либо уберите перед promotion")
    return {"atype": "promote_change", "document": doc_id,
            "entry": entry, "change": change_id, "payload": action["payload"],
            "acceptance": action.get("acceptance"), "meta": meta,
            "old_path": old_path, "evidence_dir": evidence_dir,
            "revision_from": entry["revision"],
            "revision_to": entry["revision"] + 1,
            "moves": {}, "dir_moves": {}, "file_moves": {}, "top_moves": [],
            "materials": [], "external": [], "blocked": []}


def _splice_meta(text, meta):
    """Заменить блок метаданных новым содержимым, тело не меняется."""
    positions = documents._meta_positions(text.splitlines())
    if positions is None or isinstance(positions, str):
        return None
    start, end = positions
    raw = json.dumps(meta, ensure_ascii=False, indent=2)
    block = [documents.META_START, "```json", *raw.splitlines(), "```",
             documents.META_END]
    lines = text.split("\n")
    return "\n".join(lines[:start] + block + lines[end + 1:])


def _emptied_dirs(root, doc_parent_rel, removes, require):
    """Каталоги под активным каталогом документа, опустевшие после removes."""
    candidates = set()
    parent = PurePosixPath(doc_parent_rel)
    for rel in removes:
        current = PurePosixPath(rel).parent
        while current != parent and current.is_relative_to(parent):
            candidates.add(str(current))
            current = current.parent
    result = []
    for rel in sorted(candidates,
                      key=lambda item: -len(PurePosixPath(item).parts)):
        path = root / rel
        if not path.is_dir():
            continue
        files = [item for item in path.rglob("*") if item.is_file()]
        if files and all(_rel(root, item) in removes for item in files):
            result.append(rel)
    return result


def _remap_meta_materials(meta, moves, companion_rel, plan_id, root,
                          safe_path):
    """Источники локальных материалов по карте переносов + запись
    сопровождающего доказательства этой операции."""
    new_materials = []
    for material in meta.get("materials") or []:
        item = dict(material)
        if item.get("storage") == "local":
            mapped = document_links.map_path(
                safe_path(root, item["source"]).resolve(), moves)
            item["source"] = mapped.relative_to(root).as_posix()
        new_materials.append(item)
    new_materials.append({"id": f"lifecycle-{plan_id}", "role": "report",
                          "source": companion_rel, "storage": "local",
                          "required": True, "immutable": True,
                          "used_by": []})
    return new_materials


def _claim_target(inputs, rel, root, safe_path, require):
    """Новый путь операции: свободен и отмечен в снимке входов."""
    require(inputs.get(rel, "missing") == "missing"
            and not safe_path(root, rel).exists(),
            f"Назначение занято: {rel}")
    inputs[rel] = "missing"


def _unit_summary(root, unit):
    """Строка сводки действия для плана и предпросмотра."""
    atype = unit["atype"]
    if atype == "archive_document":
        return (f"archive_document {unit['document']}: "
                f"{_rel(root, unit['old_path'])} → "
                f"{_rel(root, unit['new_path'])} "
                f"(материалов: {len(unit['materials'])}, "
                f"причина: {unit['reason']})")
    if atype == "close_task":
        return (f"close_task {unit['task']}: "
                f"{_rel(root, unit['old_path'])} → "
                f"{_rel(root, unit['new_path'])} ({unit['outcome']})")
    if atype == "reopen":
        blocked = (f"; заблокированы зависимые: {', '.join(unit['blocked'])}"
                   if unit["blocked"] else "")
        return (f"reopen {unit['task']}: "
                f"{_rel(root, unit['old_path'])} → "
                f"{_rel(root, unit['new_path'])} "
                f"({unit['status']}){blocked}")
    return (f"promote_change {unit['document']}: ревизия "
            f"{unit['revision_from']} → {unit['revision_to']}, "
            f"изменение '{unit['change']}' принято")


def _companion_body(unit, plan_id, at, norm, root):
    """Сопровождающий JSON-доказательство действия."""
    files = [{"from": _rel(root, old), "to": _rel(root, new),
              "sha256": file_operations.sha256(old.read_bytes()),
              "bytes": old.stat().st_size}
             for old, new in sorted(unit["file_moves"].items())]
    body = {"schema_version": 1, "plan_id": plan_id, "at": at,
            "actor": norm["actor"], "basis": norm["basis"],
            "action": unit["atype"],
            "files": files,
            "moves": [{"from": _rel(root, old), "to": _rel(root, new)}
                      for old, new in unit["top_moves"]],
            "materials": unit["materials"],
            "external": unit["external"]}
    atype = unit["atype"]
    if atype == "archive_document":
        body.update(type="lifecycle-archive", document=unit["document"],
                    reason=unit["reason"], successor=unit["successor"])
    elif atype == "close_task":
        task_meta = unit["task_meta"] or {}
        body.update(type="lifecycle-close", task=unit["task"],
                    outcome=unit["outcome"],
                    previous_status=unit["record"]["status"],
                    reason=unit["reason"],
                    acceptance_ref=unit["acceptance"],
                    policy="managed" if unit["meta"] is not None
                    else "legacy",
                    handoff=task_meta.get("handoff"),
                    acceptance=task_meta.get("acceptance"))
    elif atype == "reopen":
        body.update(type="lifecycle-reopen", task=unit["task"],
                    status=unit["status"], reason=unit["reason"],
                    previous_status=unit["record"]["status"],
                    previous_closed=unit["record"]["closed"],
                    policy="managed" if unit["meta"] is not None
                    else "legacy",
                    blocked=unit["blocked"])
    else:  # promote_change
        body.update(type="lifecycle-promote", document=unit["document"],
                    change=unit["change"],
                    revision_from=unit["revision_from"],
                    revision_to=unit["revision_to"],
                    acceptance=unit["acceptance"],
                    payload_sha256=file_operations.sha256(
                        unit["payload"].encode("utf-8")))
    return body


def _write_close(root, unit, moves, inputs, plan_id, at, projected_records,
                 safe_path, require):
    """Запись закрываемой карточки: статус, Closed, метаданные, ссылки."""
    old_path, new_path = unit["old_path"], unit["new_path"]
    old_rel, new_rel = _rel(root, old_path), _rel(root, new_path)
    companion_rel = _rel(root, unit["evidence_dir"]
                         / f"close-{plan_id}.json")
    _claim_target(inputs, companion_rel, root, safe_path, require)
    text = _close_text(old_path.read_text(encoding="utf-8"),
                       unit["outcome"], at, unit["task"], require)
    if unit["meta"] is not None:
        meta = dict(unit["meta"])
        meta["moves"] = list(meta.get("moves") or []) + [
            {"from": _rel(root, old), "to": _rel(root, new)}
            for old, new in unit["top_moves"]]
        meta["materials"] = _remap_meta_materials(meta, moves, companion_rel,
                                                  plan_id, root, safe_path)
        errors = []
        documents._validate_task_meta(meta, new_rel, errors)
        require(not errors, "\n".join(errors))
        merged = _splice_meta(text, meta)
        require(merged is not None, f"{old_rel}: блок метаданных не найден")
        text = merged
    rewritten = document_links.rewrite(text, old_path.resolve(),
                                       new_path.resolve(), moves)
    writes_value = rewritten["text"].encode("utf-8")
    record = projected_records[unit["task"]]
    record.update(status=unit["outcome"], closed=at,
                  closed_ts=dt.datetime.fromisoformat(at),
                  path=new_path, archived=True)
    return new_rel, writes_value, companion_rel


def _write_reopen(root, unit, moves, inputs, plan_id, at, norm, records,
                  projected_records, writes, update_by_resolved, handled,
                  safe_path, require):
    """Возврат карточки и блокировка её активных зависимых."""
    old_path, new_path = unit["old_path"], unit["new_path"]
    old_rel, new_rel = _rel(root, old_path), _rel(root, new_path)
    companion_rel = _rel(root, unit["evidence_dir"]
                         / f"reopen-{plan_id}.json")
    _claim_target(inputs, companion_rel, root, safe_path, require)
    text = _reopen_text(old_path.read_text(encoding="utf-8"),
                        unit["record"], unit["status"], unit["reason"],
                        at, norm["actor"], require)
    if unit["meta"] is not None:
        meta = dict(unit["meta"])
        # Переданное состояние приёмки сбрасывается: история остаётся
        # в архивных материалах и сопровождающих JSON.
        meta.pop("handoff", None)
        meta.pop("acceptance", None)
        meta["moves"] = list(meta.get("moves") or []) + [
            {"from": _rel(root, old), "to": _rel(root, new)}
            for old, new in unit["top_moves"]]
        meta["materials"] = _remap_meta_materials(meta, moves, companion_rel,
                                                  plan_id, root, safe_path)
        errors = []
        documents._validate_task_meta(meta, new_rel, errors)
        require(not errors, "\n".join(errors))
        merged = _splice_meta(text, meta)
        require(merged is not None, f"{old_rel}: блок метаданных не найден")
        text = merged
    rewritten = document_links.rewrite(text, old_path.resolve(),
                                       new_path.resolve(), moves)
    writes[new_rel] = rewritten["text"].encode("utf-8")
    record = projected_records[unit["task"]]
    record.update(status=unit["status"], closed="-", closed_ts=None,
                  path=new_path, archived=False)
    for dep_id in unit["blocked"]:
        dep_rec = records[dep_id]
        dep_path = dep_rec["path"]
        dep_text = _blocked_text(dep_path.read_text(encoding="utf-8"),
                                 dep_id, unit["task"], at, norm["actor"],
                                 require)
        dep_text = document_links.rewrite(
            dep_text, dep_path.resolve(), dep_path.resolve(),
            moves)["text"]
        writes[_rel(root, dep_path)] = dep_text.encode("utf-8")
        handled.add(dep_path.resolve())
        projected_records[dep_id]["status"] = "blocked"
    return companion_rel


def _write_promote(root, unit, inputs, plan_id, at, projected_docs,
                   safe_path, require):
    """Promotion: новое тело документа + снимок прежней редакции."""
    old_path = unit["old_path"]
    old_rel = _rel(root, old_path)
    revision_rel = _rel(root, unit["evidence_dir"]
                        / f"revision-{unit['revision_from']}.md")
    companion_rel = _rel(root, unit["evidence_dir"]
                         / f"promote-{plan_id}.json")
    _claim_target(inputs, revision_rel, root, safe_path, require)
    _claim_target(inputs, companion_rel, root, safe_path, require)
    text = old_path.read_text(encoding="utf-8")
    positions = documents._meta_positions(text.splitlines())
    require(isinstance(positions, tuple),
            f"{old_rel}: нет блока метаданных")
    _, end = positions
    lines = text.split("\n")
    body_old = "\n".join(lines[end + 1:]).strip("\n")
    new_text = "\n".join(lines[:end + 1]) + "\n\n" \
        + unit["payload"].rstrip("\n") + "\n"
    meta = dict(unit["meta"])
    meta["current_revision"] = unit["revision_to"]
    meta["updated_at"] = at
    changes = []
    for change in meta.get("changes") or []:
        item = dict(change)
        if item.get("id") == unit["change"]:
            item["state"] = "accepted"
            item["acceptance"] = unit["acceptance"]
        changes.append(item)
    meta["changes"] = changes
    material_ids = {item.get("id")
                    for item in meta.get("materials") or []}
    for ident in (f"revision-{unit['revision_from']}",
                  f"lifecycle-{plan_id}"):
        require(ident not in material_ids,
                f"{unit['document']}: материал '{ident}' уже "
                "зарегистрирован")
    meta["materials"] = list(meta.get("materials") or []) + [
        {"id": f"revision-{unit['revision_from']}", "role": "other",
         "source": revision_rel, "storage": "local",
         "required": True, "immutable": True, "used_by": []},
        {"id": f"lifecycle-{plan_id}", "role": "report",
         "source": companion_rel, "storage": "local",
         "required": True, "immutable": True, "used_by": []}]
    errors = []
    documents._validate_document(meta, old_path, unit["entry"]["kind"],
                                 False, errors)
    require(not errors, "\n".join(errors))
    merged = _splice_meta(new_text, meta)
    require(merged is not None, f"{old_rel}: блок метаданных не найден")
    # Снимок прежней редакции без блока метаданных (файл вне коллекции);
    # ссылки пересчитаны под расположение в evidence-каталоге.
    revision_path = safe_path(root, revision_rel)
    title = documents._doc_title(text) or old_path.stem
    snapshot = (f"# {title} — редакция {unit['revision_from']}\n\n"
                f"Снимок прежней редакции {unit['document']} "
                f"(зафиксирована при promotion {at}).\n\n"
                + body_old + "\n")
    snapshot = document_links.rewrite(
        snapshot, old_path.resolve(), revision_path.resolve(), {})["text"]
    record = dict(unit["entry"])
    record["revision"], record["updated_at"] = unit["revision_to"], at
    record["changes"] = changes
    projected_docs[unit["entry"]["id"]] = record
    return {old_rel: merged.encode("utf-8"),
            revision_rel: snapshot.encode("utf-8")}, companion_rel


def build_plan(root, request, at, ctx, safe_path, require):
    """(plan, writes) — детерминированный план по запросу и текущему дереву.

    writes — {rel: bytes}; в plan записываются только sha256 содержимого.
    Повторный вызов при неизменных входах и том же ``at`` даёт идентичный
    результат — именно это проверяет apply.
    """
    data, paths = ctx["config"](root)
    records = ctx["read_tasks"](root, paths)
    catalog = documents.load_catalog(root, data, paths, records,
                                     safe_path, require)
    norm = validate_request(request, require)
    actions = norm["actions"]
    doc_targets = {item["document"] for item in actions
                   if "document" in item}
    for item in actions:
        if item["action"] == "archive_document":
            require(item["successor"] not in doc_targets,
                    f"{item['document']}: преемник '{item['successor']}' сам "
                    "архивируется этой операцией")
    units = []
    for item in actions:
        kind = item["action"]
        if kind == "archive_document":
            require(catalog is not None,
                    "Раздел documents не настроен в project.json")
            units.append(_plan_archive(root, catalog, paths, item, at,
                                       safe_path, require))
        elif kind == "promote_change":
            require(catalog is not None,
                    "Раздел documents не настроен в project.json")
            units.append(_plan_promote(root, catalog, paths, item, at,
                                       safe_path, require))
        elif kind == "close_task":
            units.append(_plan_close(root, catalog, paths, records, item,
                                     at, ctx, safe_path, require))
        else:
            units.append(_plan_reopen(root, catalog, paths, records, item,
                                      at, ctx, safe_path, require))
    # Целевой граф статусов: действия + автоблокировка зависимых
    # возвращённых карточек; недопустимый результат отклоняется.
    status_map = {ident: rec["status"] for ident, rec in records.items()}
    targeted = set()
    for unit in units:
        if unit["atype"] == "close_task":
            status_map[unit["task"]] = unit["outcome"]
            targeted.add(unit["task"])
        elif unit["atype"] == "reopen":
            status_map[unit["task"]] = unit["status"]
            targeted.add(unit["task"])
    for unit in (item for item in units if item["atype"] == "reopen"):
        for other in records.values():
            if unit["task"] not in other["deps"] or other["archived"] \
                    or other["id"] in targeted:
                continue
            if status_map[other["id"]] in BLOCKABLE_STATES:
                status_map[other["id"]] = "blocked"
                unit["blocked"].append(other["id"])
        unit["blocked"].sort()
    bad = [(ident, dep) for ident, rec in records.items()
           if status_map[ident] in {"ready", "in_progress", "in_review",
                                    "done"}
           for dep in rec["deps"] if status_map[dep] != "done"]
    require(not bad,
            "Операция оставила бы недопустимый граф статусов: " + "; ".join(
                f"{ident} требует завершённый {dep}"
                for ident, dep in sorted(bad)))
    # Единая карта переносов: конфликт назначений (разные источники в один
    # путь) — отказ; один источник в moves и dir_moves дублируется законно.
    moves, file_moves, destinations = {}, {}, {}
    for unit in units:
        for old, new in unit["moves"].items():
            require(old not in moves or moves[old] == new,
                    f"Перенос {_rel(root, old)} конфликтует между действиями")
            moves[old] = new
        file_moves.update(unit["file_moves"])
        for old, new in unit["dir_moves"].items():
            moves.setdefault(old, new)
        for old, new in list(unit["moves"].items()) + \
                list(unit["dir_moves"].items()):
            previous = destinations.setdefault(new, old)
            require(previous == old,
                    f"Коллизия назначений: {_rel(root, new)} от "
                    f"{_rel(root, previous)} и {_rel(root, old)}")
    destinations = sorted(destinations)
    # Записи: документы/карточки на новых местах, материалы, затронутые
    # ссылки, индексы, сопровождающие JSON. Удаления: исходные пути.
    handled = {unit["old_path"].resolve() for unit in units
               if "old_path" in unit}
    removes = sorted(_rel(root, old) for old in file_moves)
    remove_dirs = []
    for unit in units:
        if "old_path" not in unit:
            continue
        doc_rel = _rel(root, unit["old_path"].parent)
        remove_dirs += _emptied_dirs(root, doc_rel, set(removes), require)
        remove_dirs += [_rel(root, item) for item in unit["dir_moves"]]
    remove_dirs = sorted(set(remove_dirs))
    # Пустые переносимые каталоги пересоздаются в архиве явно.
    create_dirs = sorted({
        _rel(root, dst_dir)
        for unit in units for src_dir, dst_dir in unit["dir_moves"].items()
        if not any(item.is_file() for item in src_dir.rglob("*"))})
    # Сканируемый набор ссылок: весь проектный scan-set + переносимые .md
    # материалы вне него (например, в work/verification).
    scan = [item for item in ctx["scan_files"](root, paths)
            if item.is_file()
            and item.resolve() != paths["task_index"].resolve()]
    known = {item.resolve() for item in scan}
    scan += [old for old in sorted(file_moves)
             if old.suffix == ".md" and old not in known]
    managed = [safe_path(root, ctx["core_prefix"]).resolve()]
    frozen = list(catalog["immutable"]) if catalog is not None else []
    result = document_links.plan_rewrites(
        scan, moves, root.resolve(), managed=managed, frozen=frozen)
    require(not result["conflicts"],
            "Ссылки требуют ручного разбора:\n" + "\n".join(
                f"  {item['path']}:{item['line']} {item['kind']} "
                f"{item['detail']}" for item in result["conflicts"]))
    updates = result["updates"]
    index_paths = ({cols["index"].resolve()
                    for cols in catalog["collections"].values()}
                   if catalog is not None else set())
    # Входы: весь scan-set ссылок, карточки, конфигурация, переносимое и
    # удаляемое содержимое, отсутствие будущих путей и пустых каталогов.
    input_rels = {_rel(root, item) for item in scan}
    input_rels.add(_rel(root, paths["task_index"]))
    input_rels.update(_rel(root, rec["path"]) for rec in records.values())
    input_rels.add(ctx["core_prefix"] + "/project.json")
    input_rels.add(ctx["core_prefix"] + "/VERSION")
    input_rels.update(removes)
    input_rels.update(remove_dirs)
    input_rels.update(_rel(root, dst) for dst in destinations)
    input_rels.update(create_dirs)
    inputs = file_operations.snapshot_paths(root, sorted(input_rels),
                                            safe_path, require)
    for dst in destinations:
        require(inputs[_rel(root, dst)] == "missing",
                f"Назначение занято: {_rel(root, dst)}")
    # plan_id привязан к запросу и пред-образу входов, но не к байтам
    # записей: operation_id и материалы-доказательства содержат plan_id.
    plan_id = "lc-" + file_operations.sha256(_canonical(
        {"request": norm, "created_at": at, "inputs": inputs,
         "moves": {_rel(root, old): _rel(root, new)
                   for old, new in sorted(moves.items())},
         "removes": removes, "remove_dirs": remove_dirs,
         "create_dirs": create_dirs}).encode("utf-8"))[7:23]
    writes = {}
    update_by_resolved = {path.resolve(): info
                          for path, info in updates.items()}
    projected_docs = dict(catalog["documents"]) if catalog is not None else {}
    projected_records = {ident: dict(rec)
                         for ident, rec in records.items()}
    companions = []
    for unit in units:
        atype = unit["atype"]
        if atype == "archive_document":
            entry, old_path, new_path = \
                unit["entry"], unit["old_path"], unit["new_path"]
            old_rel = _rel(root, old_path)
            companion_rel = _rel(root, unit["evidence_dir"]
                                 / f"archive-{plan_id}.json")
            _claim_target(inputs, companion_rel, root, safe_path, require)
            meta_errors = []
            meta = documents.parse_meta(
                old_path.read_text(encoding="utf-8"), old_rel, meta_errors)
            require(not meta_errors and meta is not None,
                    f"{old_rel}: метаданные не разбираются")
            meta = dict(meta)
            meta["archive"] = {"at": at, "reason": unit["reason"],
                               "successor": unit["successor"],
                               "operation_id": plan_id,
                               "original_path": old_rel}
            meta["updated_at"] = at
            meta["moves"] = list(meta.get("moves") or []) + [
                {"from": _rel(root, old), "to": _rel(root, new)}
                for old, new in unit["top_moves"]]
            meta["materials"] = _remap_meta_materials(
                meta, moves, companion_rel, plan_id, root, safe_path)
            errors = []
            documents._validate_document(meta, new_path, entry["kind"], True,
                                         errors)
            require(not errors, "\n".join(errors))
            merged = _splice_meta(old_path.read_text(encoding="utf-8"),
                                  meta)
            require(merged is not None,
                    f"{old_rel}: блок метаданных не найден")
            rewritten = document_links.rewrite(
                merged, old_path.resolve(), new_path.resolve(), moves)
            writes[_rel(root, new_path)] = \
                rewritten["text"].encode("utf-8")
            record = dict(entry)
            record["path"], record["archived"] = new_path, True
            record["archive"], record["updated_at"] = meta["archive"], at
            projected_docs[entry["id"]] = record
            companions.append((companion_rel, unit))
        elif atype == "close_task":
            new_rel, content, companion_rel = _write_close(
                root, unit, moves, inputs, plan_id, at,
                projected_records, safe_path, require)
            writes[new_rel] = content
            companions.append((companion_rel, unit))
        elif atype == "reopen":
            companion_rel = _write_reopen(
                root, unit, moves, inputs, plan_id, at, norm, records,
                projected_records, writes, update_by_resolved, handled,
                safe_path, require)
            companions.append((companion_rel, unit))
        else:  # promote_change
            produced, companion_rel = _write_promote(
                root, unit, inputs, plan_id, at, projected_docs,
                safe_path, require)
            writes.update(produced)
            companions.append((companion_rel, unit))
    # Материалы и прочие переносимые файлы — байты на новых путях, плюс
    # переписанные непереносимые файлы с затронутыми ссылками.
    for old, new in sorted(file_moves.items()):
        if old in handled:
            continue
        info = update_by_resolved.get(old)
        if info is not None:
            writes[_rel(root, new)] = info["updated"].encode("utf-8")
        else:
            writes[_rel(root, new)] = old.read_bytes()
    for path, info in updates.items():
        resolved = path.resolve()
        if resolved in file_moves or resolved in index_paths \
                or resolved in handled:
            continue
        writes[_rel(root, resolved)] = info["updated"].encode("utf-8")
    # Индексы затронутых коллекций — перегенерация области + правка ссылок
    # ручной части.
    kinds = {unit["entry"]["kind"] for unit in units
             if "entry" in unit} if catalog is not None else set()
    if kinds:
        projected = {**catalog, "documents": projected_docs}
        for kind in sorted(kinds):
            index_write = ctx["collection_index_write"](root, projected,
                                                        kind)
            if index_write is None:
                continue
            rel, content = index_write
            index = catalog["collections"][kind]["index"]
            text = document_links.rewrite(content.decode("utf-8"),
                                          index.resolve(), index.resolve(),
                                          moves)["text"]
            writes[rel] = text.encode("utf-8")
    # Индекс задач — при любых действиях над карточками.
    if any(unit["atype"] in TASK_ACTIONS for unit in units):
        index = paths["task_index"]
        if index.exists():
            require(index.read_text(encoding="utf-8")
                    .startswith(ctx["task_index_header"]),
                    "Конфликт: индекс указывает на чужой документ; "
                    "запись отменена")
        writes[_rel(root, index)] = ctx["render_task_index"](
            projected_records, index.parent).encode("utf-8")
    # Сопровождающие JSON-доказательства — последним шагом, когда известен
    # полный состав переносов.
    for companion_rel, unit in companions:
        body = _companion_body(unit, plan_id, at, norm, root)
        writes[companion_rel] = \
            (json.dumps(body, ensure_ascii=False, indent=2) + "\n") \
            .encode("utf-8")
    summary = [_unit_summary(root, unit) for unit in units]
    plan_obj = {"schema_version": PLAN_SCHEMA, "kind": "lifecycle-plan",
                "plan_id": plan_id, "created_at": at, "root": str(root),
                "tool": {"name": "playbook.py",
                         "version": ctx["version"](root)},
                "request": norm, "summary": summary,
                "moves": {_rel(root, old): _rel(root, new)
                          for old, new in sorted(moves.items())},
                "inputs": inputs,
                "writes": {rel: file_operations.sha256(content)
                           for rel, content in sorted(writes.items())},
                "removes": removes, "remove_dirs": remove_dirs,
                "create_dirs": create_dirs}
    return plan_obj, writes


def _actor_label(actor):
    label = f"{actor.get('name')} ({actor.get('role')}"
    if actor.get("model"):
        label += f", {actor['model']}"
    return label + ")"


def _preview(root, plan, writes):
    lines = [f"План {plan['plan_id']} (lifecycle):",
             f"Основание: {plan['request']['basis']}",
             f"Исполнитель: {_actor_label(plan['request']['actor'])}",
             "Действия:"]
    lines += [f"  {line}" for line in plan["summary"]]
    lines.append("Переносы:")
    lines += [f"  {old} → {new}"
              for old, new in sorted(plan["moves"].items())]
    if plan["create_dirs"]:
        lines.append("Создаются пустые каталоги:")
        lines += [f"  {rel}" for rel in plan["create_dirs"]]
    if plan["remove_dirs"]:
        lines.append("Удаляются каталоги:")
        lines += [f"  {rel}" for rel in plan["remove_dirs"]]
    lines.append(f"Записей: {len(plan['writes'])}, "
                 f"удалений файлов: {len(plan['removes'])}")
    lines.append("Diff записей (.md):")
    for rel in sorted(plan["writes"]):
        if not rel.endswith(".md"):
            continue
        path = root / rel
        old = path.read_text(encoding="utf-8") if path.is_file() else ""
        diff = difflib.unified_diff(old.splitlines(keepends=True),
                                    writes[rel].decode("utf-8")
                                    .splitlines(keepends=True),
                                    fromfile=f"a/{rel}" if old else "/dev/null",
                                    tofile=f"b/{rel}")
        lines.append("".join(diff).rstrip("\n"))
    return "\n".join(lines)


def _read_request(root, rel, safe_path, require):
    path = safe_path(root, rel)
    require(path.is_file() and not path.is_symlink(),
            f"Нет файла запроса: {rel}")
    try:
        data = json.loads(path.read_text(encoding="utf-8"),
                          object_pairs_hook=documents._unique_pairs)
    except ValueError as error:
        require(False, f"{rel}: {error}")
    return data


def _save_plan(root, plan, safe_path, require):
    """Атомарная запись плана в work/lifecycle/plans/<plan_id>.json."""
    directory = safe_path(root, PLANS_DIR)
    directory.mkdir(parents=True, exist_ok=True)
    target = directory / f"{plan['plan_id']}.json"
    temp = directory / f".{plan['plan_id']}.{os.getpid()}.tmp"
    temp.write_text(json.dumps(plan, ensure_ascii=False, indent=2) + "\n",
                    encoding="utf-8")
    os.replace(temp, target)
    return target


def plan_command(root, request_rel, save, ctx, safe_path, require):
    request = _read_request(root, request_rel, safe_path, require)
    plan, writes = build_plan(root, request, file_operations.now_iso(),
                              ctx, safe_path, require)
    print(_preview(root, plan, writes))
    if not save:
        print("\nПредпросмотр, без записи; сохранение плана: --save")
        return
    target = _save_plan(root, plan, safe_path, require)
    print(f"\nПлан записан: {_rel(root, target)}")
    print("Применение: playbook.py lifecycle apply "
          f"{_rel(root, target)}")


def _load_plan(root, rel, safe_path, require):
    path = safe_path(root, rel)
    require(path.is_file() and not path.is_symlink(),
            f"Нет файла плана: {rel}")
    try:
        plan = json.loads(path.read_text(encoding="utf-8"),
                          object_pairs_hook=documents._unique_pairs)
    except ValueError as error:
        require(False, f"{rel}: {error}")
    require(isinstance(plan, dict)
            and plan.get("kind") == "lifecycle-plan"
            and plan.get("schema_version") == PLAN_SCHEMA,
            f"{rel}: не план lifecycle-операции")
    for field in ("plan_id", "created_at", "root"):
        require(isinstance(plan.get(field), str) and plan[field].strip(),
                f"{rel}: нет поля '{field}'")
    require(isinstance(plan.get("request"), dict),
            f"{rel}: нет поля 'request'")
    for field in ("moves", "inputs", "writes"):
        require(isinstance(plan.get(field), dict),
                f"{rel}: поле '{field}' — объект")
    for field in ("removes", "remove_dirs", "create_dirs", "summary"):
        require(isinstance(plan.get(field), list),
                f"{rel}: поле '{field}' — список")
    require(plan["root"] == str(root),
            f"{rel}: план построен для другого корня проекта")
    return plan


def _consistency(ctx, kinds, has_tasks, label, safe_path, require):
    """Проверка каталога, индексов затронутых коллекций, индекса задач
    и ссылок дерева в проверяемом корне."""
    def check(staged_root):
        data, paths = ctx["config"](staged_root)
        records = ctx["read_tasks"](staged_root, paths)
        catalog = documents.load_catalog(staged_root, data, paths, records,
                                         safe_path, require)
        if kinds:
            require(catalog is not None,
                    f"{label}: каталог документов недоступен")
        errors = []
        if catalog is not None:
            for kind in kinds:
                index = catalog["collections"][kind]["index"]
                rel = index.relative_to(staged_root).as_posix()
                if not index.is_file():
                    errors.append(f"{rel}: нет файла индекса")
                    continue
                text = index.read_text(encoding="utf-8")
                expected = documents.splice_index(
                    text, documents.index_region(catalog, kind))
                if expected is None or expected != text:
                    errors.append(f"{rel}: индекс не соответствует каталогу")
        if has_tasks:
            index = paths["task_index"]
            if not index.is_file() \
                    or index.read_text(encoding="utf-8") \
                    != ctx["render_task_index"](records, index.parent):
                errors.append("индекс задач не соответствует карточкам")
        require(not errors, f"{label}: " + "; ".join(errors))
        ctx["check_links"](staged_root, paths, catalog)
    return check


def run_plan(root, plan, writes, ctx, safe_path, require):
    """Спецификация file_operations для готового (plan, writes) и запуск."""
    actions = plan["request"]["actions"]
    kinds = {action["document"].split(":", 1)[0]
             for action in actions if "document" in action}
    has_tasks = any(action["action"] in TASK_ACTIONS for action in actions)
    checks = [_consistency(ctx, kinds, has_tasks, "staged", safe_path,
                           require),
              _consistency(ctx, kinds, has_tasks, "final", safe_path,
                           require)]
    spec = {"operation": "lifecycle",
            "plan_id": plan["plan_id"],
            "actor": _actor_label(plan["request"]["actor"]),
            "basis": plan["request"]["basis"],
            "writes": writes, "removes": plan["removes"],
            "remove_dirs": plan["remove_dirs"],
            "create_dirs": plan["create_dirs"],
            "inputs": plan["inputs"],
            "staged_checks": [checks[0]], "final_checks": [checks[1]],
            "moves": plan["moves"],
            "receipt": {"actions": plan["summary"],
                        "plan": f"{PLANS_DIR}/{plan['plan_id']}.json"}}
    return ctx["run_operation"](root, spec)


def apply_command(root, plan_rel, ctx, safe_path, require):
    """Применить сохранённый план: пересборка, сверка и запуск engine."""
    plan = _load_plan(root, plan_rel, safe_path, require)
    # Повторное применение уже завершённого плана — короткий ответ до
    # пересборки: документ давно в архиве, и повторный plan был бы отказом.
    # Решение принимается под удерживаемым командным gate и специализирован-
    # ным lock операции — как find_completed внутри run_operation.
    lock = file_operations._operation_lock(root, safe_path)
    if lock is not None:
        try:
            prior = file_operations.find_completed(root, plan["plan_id"]) \
                if file_operations.pending_info(root) is None else None
        finally:
            lock.close()
        if prior is not None:
            print(f"План {plan['plan_id']} уже применён операцией {prior} — "
                  "повторное применение пропущено.")
            return {"status": "already_completed",
                    "plan_id": plan["plan_id"], "op_id": prior}
    rebuilt, writes = build_plan(root, plan["request"], plan["created_at"],
                                 ctx, safe_path, require)
    stale = [field for field in ("plan_id", "inputs", "writes", "removes",
                                 "remove_dirs", "create_dirs", "moves")
             if rebuilt[field] != plan[field]]
    require(not stale,
            f"План устарел или подменён ({', '.join(stale)}): входы "
            "изменились — постройте план заново командой lifecycle plan")
    result = run_plan(root, rebuilt, writes, ctx, safe_path, require)
    if result["status"] == "already_completed":
        print(f"План {plan['plan_id']} уже применён операцией "
              f"{result['op_id']} — повторное применение пропущено.")
    else:
        print(f"План {plan['plan_id']} применён. "
              f"Операция: {result['op_dir']}")
    return result


def status(root, safe_path, require):
    pending = file_operations.pending_info(root)
    if pending is not None:
        print(f"Незавершённая операция документов: {pending.get('op_id')} "
              f"({pending.get('operation')}, {pending.get('started_at')})")
        op_dir = pending.get("op_dir")
        probe = file_operations._lock_stream(root, safe_path,
                                             file_operations.LOCK_FILE)
        if probe is None:
            print("Состояние: выполняется другим процессом — восстановление "
                  "запрещено до завершения.")
        else:
            probe.close()
            print(f"Состояние: прервана. Восстановление: "
                  f"python3 {op_dir}/restore.py либо playbook.py "
                  "lifecycle restore")
    else:
        print("Незавершённых операций документов нет.")
    directory = safe_path(root, PLANS_DIR)
    saved = sorted(directory.glob("*.json")) if directory.is_dir() else []
    if saved:
        print(f"Сохранённые планы ({len(saved)}):")
        for path in saved:
            try:
                plan = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                plan = {}
            count = len((plan.get("request") or {}).get("actions") or [])
            print(f"  {path.name}: {plan.get('created_at', '?')}, "
                  f"действий: {count}")
    else:
        print("Сохранённых планов нет.")


def restore(root, safe_path, require):
    result = file_operations.restore_operation(root, safe_path, require)
    if result["status"] == "aborted_before_write":
        print(f"Операция прервана до записи: изменений не было, маркер снят. "
              f"Каталог: {result['op_dir']}")
    else:
        conflicts = (f" Конфликтующее содержимое: "
                     f"{result['op_dir']}/conflicts/ "
                     f"({', '.join(result['conflicts'])})"
                     if result["conflicts"] else "")
        print(f"Восстановлено из резервной копии: {result['restored']} файлов, "
              f"удалено {result['removed']}.{conflicts} "
              f"Каталог: {result['op_dir']}")
    return result


def _managed_card(root, records, task_id, safe_path, require):
    """(rec, rel, text, meta) активной карточки с блоком метаданных."""
    rec = records.get(task_id)
    require(rec is not None, f"Нет задачи: {task_id}")
    require(not rec["archived"],
            f"{task_id}: карточка в архиве — записи передачи/приёмки "
            "добавляются до закрытия")
    rel = _rel(root, rec["path"])
    text, meta = _task_meta(rec["path"], rel, require)
    require(meta is not None,
            f"{task_id}: карточка без метаданных — handoff/accept требуют "
            "раздел documents в project.json и блок метаданных карточки")
    return rec, rel, text, meta


def _verify_runs(root, task_id, safe_path):
    """(каталог прогона, report.json) для всех запусков verify задачи."""
    base = safe_path(root, f"work/verification/{task_id}")
    if not base.is_dir():
        return []
    return [(child, child / "report.json")
            for child in sorted(base.iterdir())
            if child.is_dir() and not child.is_symlink()]


def _write_card_meta(root, rel, text, meta, label, actor, basis, ctx,
                     safe_path, require):
    """Splice + валидация + запись карточки одной операцией engine."""
    errors = []
    documents._validate_task_meta(meta, rel, errors)
    require(not errors, "\n".join(errors))
    merged = _splice_meta(text, meta)
    require(merged is not None, f"{rel}: блок метаданных не найден")
    writes = {rel: merged.encode("utf-8")}

    def check(staged_root):
        staged = staged_root / rel
        staged_errors = []
        parsed = documents.parse_meta(
            staged.read_text(encoding="utf-8"), rel, staged_errors)
        require(not staged_errors and parsed == meta,
                f"{label}: карточка изменилась после подготовки записи")

    inputs = file_operations.snapshot_paths(root, [rel], safe_path, require)
    plan_id = "lc-" + file_operations.sha256(_canonical(
        {"op": label, "path": rel,
         "sha256": file_operations.sha256(writes[rel]),
         "inputs": inputs}).encode("utf-8"))[7:23]
    spec = {"operation": f"lifecycle {label}", "plan_id": plan_id,
            "actor": actor, "basis": basis, "writes": writes,
            "inputs": inputs, "staged_checks": [check],
            "final_checks": [check]}
    result = ctx["run_operation"](root, spec)
    return result


def handoff_command(root, task_id, summary, actor_name, actor_model,
                    reports, ctx, safe_path, require):
    """Запись передачи на приёмку: прогоны verify → materials, handoff.

    Отчёты регистрируются как immutable-материалы; в handoff.reports
    попадают только успешные прогоны с неизменными входами. Свежесть
    входов повторно проверяет close_task — передача фиксирует состав
    доказательств, а не подменяет приёмку.
    """
    data, paths = ctx["config"](root)
    records = ctx["read_tasks"](root, paths)
    rec, rel, text, meta = _managed_card(root, records, task_id, safe_path,
                                         require)
    materials = [dict(item) for item in meta.get("materials") or []]
    material_ids = {item.get("id") for item in materials}
    candidates = []
    if reports:
        for rel_path in reports:
            run_dir = safe_path(root, rel_path)
            candidates.append(
                (run_dir if run_dir.is_dir() else run_dir.parent,
                 run_dir / "report.json" if run_dir.is_dir() else run_dir))
    else:
        candidates = _verify_runs(root, task_id, safe_path)
    report_refs = []
    for run_dir, report_path in candidates:
        require(report_path.is_file(),
                f"{task_id}: нет отчёта проверки "
                f"{_rel(root, report_path)}")
        report = verification.load_report(report_path, require)
        require(report.get("task_id") == task_id,
                f"{task_id}: отчёт {_rel(root, report_path)} принадлежит "
                f"задаче {report.get('task_id')}")
        run_id = report.get("run_id") or run_dir.name
        material_id = f"verify-{run_id}"
        run_rel = _rel(root, run_dir)
        existing = next((item for item in materials
                         if item.get("id") == material_id), None)
        if existing is None:
            materials.append({"id": material_id, "role": "report",
                              "source": run_rel, "storage": "local",
                              "required": True, "immutable": True,
                              "used_by": [task_id]})
            material_ids.add(material_id)
        else:
            require(existing.get("source") == run_rel,
                    f"{task_id}: материал '{material_id}' указывает на "
                    f"{existing.get('source')}, ожидался {run_rel}")
        if report.get("status") == "passed" \
                and report.get("inputs_unchanged"):
            report_refs.append(material_id)
    require(report_refs,
            f"{task_id}: нет успешного прогона verify с неизменными "
            "входами — выполните playbook.py verify до передачи")
    at = file_operations.now_iso()
    meta = dict(meta)
    meta["materials"] = materials
    meta["handoff"] = {"at": at,
                       "actor": {"name": actor_name, "model": actor_model},
                       "summary": summary,
                       "reports": sorted(set(report_refs)),
                       "card_projection": card_projection(text)}
    result = _write_card_meta(root, rel, text, meta, "handoff",
                              f"{actor_name} (executor)", "lifecycle handoff",
                              ctx, safe_path, require)
    if result["status"] == "already_completed":
        print(f"{task_id}: такая запись передачи уже сделана — "
              "повтор пропущен.")
    else:
        print(f"{task_id}: передача на приёмку записана; отчётов: "
              f"{len(report_refs)}. Независимая приёмка: lifecycle accept.")
    return result


def accept_command(root, task_id, result, kind, role, actor_name,
                   actor_model, note, ctx, safe_path, require):
    """Запись приёмки либо диагностического протокола аудита.

    accepted требует свежей записи передачи: проекция карточки обязана
    совпадать с переданной — иначе приёмка относилась бы к другому
    состоянию требований. diagnostic протокол не является приёмкой и
    не открывает close (кроме карточек аудита без зависимостей).
    """
    data, paths = ctx["config"](root)
    records = ctx["read_tasks"](root, paths)
    rec, rel, text, meta = _managed_card(root, records, task_id, safe_path,
                                         require)
    handoff = meta.get("handoff")
    if result == "accepted":
        require(isinstance(handoff, dict),
                f"{task_id}: приёмка без записи передачи — сначала "
                "lifecycle handoff")
        require(card_projection(text) == handoff.get("card_projection"),
                f"{task_id}: карточка изменилась после передачи — "
                "приёмка относилась бы к другому состоянию требований; "
                "повторите handoff и аудит")
    at = file_operations.now_iso()
    meta = dict(meta)
    meta["acceptance"] = {"at": at,
                          "actor": {"name": actor_name,
                                    "model": actor_model},
                          "role": role, "kind": kind, "result": result,
                          "handoff_at": handoff.get("at")
                          if isinstance(handoff, dict) else None,
                          "session": None, "detail": note}
    applied = _write_card_meta(root, rel, text, meta, "accept",
                               f"{actor_name} (auditor)", "lifecycle accept",
                               ctx, safe_path, require)
    if applied["status"] == "already_completed":
        print(f"{task_id}: такая запись приёмки уже сделана — "
              "повтор пропущен.")
    else:
        print(f"{task_id}: записана приёмка result={result} kind={kind}.")
    return applied
