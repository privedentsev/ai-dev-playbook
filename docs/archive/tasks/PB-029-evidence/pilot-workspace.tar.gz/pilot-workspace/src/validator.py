def parse_age(value: str) -> int | None:
    """Парсинг возраста из строки.
    
    Возвращает int для корректных строк, либо None для пустых/пробельных строк.
    """
    cleaned = value.strip()
    if not cleaned:
        return None
    return int(cleaned)
