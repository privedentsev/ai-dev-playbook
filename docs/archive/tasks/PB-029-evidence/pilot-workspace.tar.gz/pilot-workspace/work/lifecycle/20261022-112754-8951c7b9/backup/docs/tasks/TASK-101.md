# TASK-101: Исправление ошибки валидации

ID: TASK-101
Status: in_review
Priority: P2
Depends-On: -
Executor: Antigravity
Model: Gemini 3.8 Flash (High)
Created: 2026-10-22T08:00:00+03:00
Closed: -

<!-- playbook-meta:start -->
```json
{
  "schema_version": 1,
  "relations": [],
  "materials": [
    {
      "id": "verify-ea8bdce1b3af4fa0a96d974c09579c67",
      "role": "report",
      "source": "work/verification/TASK-101/ea8bdce1b3af4fa0a96d974c09579c67",
      "storage": "local",
      "required": true,
      "immutable": true,
      "used_by": [
        "TASK-101"
      ]
    },
    {
      "id": "verify-56addcdcc459456ba7ef7846679a431f",
      "role": "report",
      "source": "work/verification/TASK-101/56addcdcc459456ba7ef7846679a431f",
      "storage": "local",
      "required": true,
      "immutable": true,
      "used_by": [
        "TASK-101"
      ]
    }
  ],
  "handoff": {
    "at": "2026-10-22T11:27:54+03:00",
    "actor": {
      "name": "Test-Harness",
      "model": "automated-cli-probe"
    },
    "summary": "CLI-зонд: исправление дефекта пустых строк и тест test_empty_age_returns_none",
    "reports": [
      "verify-56addcdcc459456ba7ef7846679a431f",
      "verify-ea8bdce1b3af4fa0a96d974c09579c67"
    ],
    "card_projection": "sha256:d94ca465e2205ef279b39ba2048c94458d746d5a953b108d3369c7b292f45108"
  },
  "acceptance": {
    "at": "2026-10-22T11:27:53+03:00",
    "actor": {
      "name": "Test-Harness",
      "model": "automated-cli-probe"
    },
    "role": "auditor",
    "kind": "diagnostic",
    "result": "accepted",
    "handoff_at": "2026-10-22T11:27:52+03:00",
    "session": null,
    "detail": "автоматическая CLI-проверка: parse_age('') падает с ValueError; ожидается возврат None"
  }
}
```
<!-- playbook-meta:end -->

## Цель и границы
Исправление ошибки валидации в одной функции.

## Приёмка
- [x] Ошибка устранена.

## Проверки и доказательства
verify

## Выполнение и проверки
2026-10-22: первичная реализация функции parse_age.
2026-10-22: устранено замечание CLI-зонда: добавлена обработка пустых и пробельных строк с возвратом None, добавлен тест test_empty_age_returns_none.

## Передача
Готово к проверке.
