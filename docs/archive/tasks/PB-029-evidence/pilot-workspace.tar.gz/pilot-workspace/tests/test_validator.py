import unittest
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.validator import parse_age

class TestValidator(unittest.TestCase):
    def test_valid_age(self):
        self.assertEqual(parse_age("25"), 25)

    def test_whitespace_age(self):
        self.assertEqual(parse_age(" 42 "), 42)

    def test_empty_age_returns_none(self):
        self.assertIsNone(parse_age(""))
        self.assertIsNone(parse_age("   "))

if __name__ == "__main__":
    unittest.main()
