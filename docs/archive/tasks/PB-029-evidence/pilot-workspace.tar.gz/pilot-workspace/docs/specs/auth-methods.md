# Методы аутентификации

<!-- playbook-meta:start -->
```json
{
  "schema_version": 1,
  "document_id": "spec:auth-methods",
  "kind": "spec",
  "state": "accepted",
  "created_at": "2026-10-22T08:00:00+03:00",
  "updated_at": "2026-10-22T11:28:32+03:00",
  "current_revision": 3,
  "relations": [
    {
      "relation": "based_on",
      "target": "adr:0010-sms-auth"
    },
    {
      "relation": "based_on",
      "target": "design:auth-sms"
    }
  ],
  "tasks": [
    "DEV-701",
    "DEV-702"
  ],
  "changes": [
    {
      "id": "ch-deprecate",
      "state": "accepted",
      "section": "## 4. Действующее поведение",
      "basis": {
        "type": "engineer_approval",
        "who": "Engineer",
        "detail": "согласован вывод SMS",
        "source": "диалог",
        "at": "2026-10-22T08:00:00+03:00"
      },
      "tasks": [
        "DEV-701"
      ],
      "acceptance": "DEV-701"
    },
    {
      "id": "ch-remove-sms",
      "state": "accepted",
      "section": "## 4. Действующее поведение",
      "basis": {
        "type": "engineer_approval",
        "who": "Engineer",
        "detail": "согласован вывод SMS",
        "source": "диалог",
        "at": "2026-10-22T08:00:00+03:00"
      },
      "tasks": [
        "DEV-702"
      ],
      "acceptance": "DEV-702"
    }
  ],
  "materials": [
    {
      "id": "revision-1",
      "role": "other",
      "source": "docs/specs/auth-methods-evidence/revision-1.md",
      "storage": "local",
      "required": true,
      "immutable": true,
      "used_by": []
    },
    {
      "id": "lifecycle-lc-f2155632eadbb99d",
      "role": "report",
      "source": "docs/specs/auth-methods-evidence/promote-lc-f2155632eadbb99d.json",
      "storage": "local",
      "required": true,
      "immutable": true,
      "used_by": []
    },
    {
      "id": "revision-2",
      "role": "other",
      "source": "docs/specs/auth-methods-evidence/revision-2.md",
      "storage": "local",
      "required": true,
      "immutable": true,
      "used_by": []
    },
    {
      "id": "lifecycle-lc-d189f9390b436ee7",
      "role": "report",
      "source": "docs/specs/auth-methods-evidence/promote-lc-d189f9390b436ee7.json",
      "storage": "local",
      "required": true,
      "immutable": true,
      "used_by": []
    }
  ],
  "archive": null
}
```
<!-- playbook-meta:end -->

## 1. Проблема и цель

Аутентификация пользователей.

## 4. Действующее поведение

Поддерживается только WebAuthn.

## 5. Планируемые изменения

Нет.

## 7. Критерии приёмки

- [x] Только WebAuthn.
