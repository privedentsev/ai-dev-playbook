# Повтор платежей

<!-- playbook-meta:start -->
```json
{
  "schema_version": 1,
  "document_id": "spec:payment-retry",
  "kind": "spec",
  "state": "accepted",
  "created_at": "2026-10-22T08:00:00+03:00",
  "updated_at": "2026-10-22T11:27:57+03:00",
  "current_revision": 2,
  "relations": [],
  "tasks": [
    "DEV-201"
  ],
  "changes": [
    {
      "id": "ch-retry",
      "state": "accepted",
      "section": "## 4. Действующее поведение",
      "basis": {
        "type": "engineer_approval",
        "who": "Engineer",
        "detail": "согласовано",
        "source": "диалог",
        "at": "2026-10-22T08:00:00+03:00"
      },
      "tasks": [
        "DEV-201"
      ],
      "acceptance": "DEV-201"
    }
  ],
  "materials": [
    {
      "id": "revision-1",
      "role": "other",
      "source": "docs/specs/payment-retry-evidence/revision-1.md",
      "storage": "local",
      "required": true,
      "immutable": true,
      "used_by": []
    },
    {
      "id": "lifecycle-lc-6cdbd934f9c25e02",
      "role": "report",
      "source": "docs/specs/payment-retry-evidence/promote-lc-6cdbd934f9c25e02.json",
      "storage": "local",
      "required": true,
      "immutable": true,
      "used_by": []
    }
  ],
  "archive": null
}
```
<!-- playbook-meta:end -->

## 1. Проблема и цель
Надёжность платежей.

## 4. Действующее поведение
Платежи выполняются с автоматическим повтором до 3 раз.

## 5. Планируемые изменения
Повтор платежа до 3 раз (принято в DEV-201).

## 7. Критерии приёмки
- [x] Повтор до 3 раз.
