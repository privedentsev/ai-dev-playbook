# Индекс задач

Сгенерировано playbook.py; статусы изменять в карточках.

## Активные

| ID | Задача | Статус | Приоритет | Исполнитель | Создана | Закрыта | Зависимости |
|---|---|---|---|---|---|---|---|
| TASK-801 | [TASK-801: Контроль evidence и отмена](TASK-801.md) | in_progress | P2 | Antigravity / Gemini 3.8 Flash (High) | 2026-10-22 08:00 | — | — |
| TASK-802 | [TASK-802: Откладывание задачи](TASK-802.md) | blocked | P2 | Antigravity / Gemini 3.8 Flash (High) | 2026-10-22 08:00 | — | — |

## Архив

| ID | Задача | Статус | Приоритет | Исполнитель | Создана | Закрыта | Зависимости |
|---|---|---|---|---|---|---|---|
| DEV-702 | [DEV-702: Полное удаление SMS](../archive/tasks/DEV-702.md) | done | P2 | Antigravity / Gemini 3.8 Flash (High) | 2026-10-22 08:00 | 2026-10-22 11:28 | — |
| DEV-701 | [DEV-701: Пометить SMS deprecated](../archive/tasks/DEV-701.md) | done | P2 | Antigravity / Gemini 3.8 Flash (High) | 2026-10-22 08:00 | 2026-10-22 11:28 | — |
| TASK-301 | [TASK-301: Проверка evidence](../archive/tasks/TASK-301.md) | done | P2 | Antigravity / Gemini 3.8 Flash (High) | 2026-10-22 08:00 | 2026-10-22 11:28 | — |
| AUDIT-1 | [AUDIT-1: Подзадача](../archive/tasks/AUDIT-1.md) | done | P2 | Antigravity / Gemini 3.8 Flash (High) | 2026-10-22 08:00 | 2026-10-22 11:28 | SUB-1, SUB-2 |
| SUB-2 | [SUB-2: Подзадача](../archive/tasks/SUB-2.md) | done | P2 | Antigravity / Gemini 3.8 Flash (High) | 2026-10-22 08:00 | 2026-10-22 11:28 | SUB-1 |
| SUB-1 | [SUB-1: Подзадача](../archive/tasks/SUB-1.md) | done | P2 | Antigravity / Gemini 3.8 Flash (High) | 2026-10-22 08:00 | 2026-10-22 11:28 | — |
| DEV-201 | [DEV-201: Реализовать повтор платежей](../archive/tasks/DEV-201.md) | done | P2 | Antigravity / Gemini 3.8 Flash (High) | 2026-10-22 08:00 | 2026-10-22 11:27 | — |
| TASK-101 | [TASK-101: Исправление ошибки валидации](../archive/tasks/TASK-101.md) | done | P2 | Antigravity / Gemini 3.8 Flash (High) | 2026-10-22 08:00 | 2026-10-22 11:27 | — |
