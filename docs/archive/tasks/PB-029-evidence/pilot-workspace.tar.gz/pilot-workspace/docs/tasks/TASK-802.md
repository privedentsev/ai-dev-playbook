# TASK-802: Откладывание задачи

ID: TASK-802
Status: blocked
Priority: P2
Depends-On: -
Executor: Antigravity
Model: Gemini 3.8 Flash (High)
Created: 2026-10-22T08:00:00+03:00
Closed: -

<!-- playbook-meta:start -->
```json
{
  "schema_version": 1,
  "relations": [],
  "materials": [],
  "moves": []
}
```
<!-- playbook-meta:end -->

## Цель и границы
Тест откладывания задачи.

## Приёмка
- [x] Отложено.

## Выполнение и проверки
2026-10-22: задача отложена до получения внешнего API ключа (postpone).

## Передача
-
