# TASK-801: Контроль evidence и отмена

ID: TASK-801
Status: in_progress
Priority: P2
Depends-On: -
Executor: Antigravity
Model: Gemini 3.8 Flash (High)
Created: 2026-10-22T08:00:00+03:00
Closed: -

<!-- playbook-meta:start -->
```json
{
  "schema_version": 1,
  "relations": [],
  "materials": [
    {
      "id": "probe-log",
      "role": "log",
      "source": "docs/tasks/TASK-801-evidence/probe.log",
      "storage": "local",
      "required": true,
      "immutable": true,
      "used_by": [
        "TASK-801"
      ]
    },
    {
      "id": "verify-f1f9f8437e2e4bd78016dc54728bad2e",
      "role": "report",
      "source": "docs/tasks/TASK-801-evidence/work/verification/TASK-801/f1f9f8437e2e4bd78016dc54728bad2e",
      "storage": "local",
      "required": true,
      "immutable": true,
      "used_by": [
        "TASK-801"
      ]
    },
    {
      "id": "lifecycle-lc-89ecf944090f48ee",
      "role": "report",
      "source": "docs/tasks/TASK-801-evidence/close-lc-89ecf944090f48ee.json",
      "storage": "local",
      "required": true,
      "immutable": true,
      "used_by": []
    },
    {
      "id": "lifecycle-lc-52d6463eb4fa1207",
      "role": "report",
      "source": "docs/tasks/TASK-801-evidence/reopen-lc-52d6463eb4fa1207.json",
      "storage": "local",
      "required": true,
      "immutable": true,
      "used_by": []
    }
  ],
  "moves": [
    {
      "from": "docs/tasks/TASK-801-evidence/probe.log",
      "to": "docs/archive/tasks/TASK-801-evidence/probe.log"
    },
    {
      "from": "work/verification/TASK-801/f1f9f8437e2e4bd78016dc54728bad2e",
      "to": "docs/archive/tasks/TASK-801-evidence/work/verification/TASK-801/f1f9f8437e2e4bd78016dc54728bad2e"
    },
    {
      "from": "docs/tasks/TASK-801.md",
      "to": "docs/archive/tasks/TASK-801.md"
    },
    {
      "from": "docs/archive/tasks/TASK-801-evidence/probe.log",
      "to": "docs/tasks/TASK-801-evidence/probe.log"
    },
    {
      "from": "docs/archive/tasks/TASK-801-evidence/work/verification/TASK-801/f1f9f8437e2e4bd78016dc54728bad2e",
      "to": "docs/tasks/TASK-801-evidence/work/verification/TASK-801/f1f9f8437e2e4bd78016dc54728bad2e"
    },
    {
      "from": "docs/archive/tasks/TASK-801-evidence/close-lc-89ecf944090f48ee.json",
      "to": "docs/tasks/TASK-801-evidence/close-lc-89ecf944090f48ee.json"
    },
    {
      "from": "docs/archive/tasks/TASK-801.md",
      "to": "docs/tasks/TASK-801.md"
    }
  ]
}
```
<!-- playbook-meta:end -->

## Цель и границы
Тест контроля.

## Приёмка
- [x] Ок.

## Проверки и доказательства
verify

## Выполнение и проверки
Готово.

## Передача
Готово.

## Возврат 2026-10-22T11:28:38+03:00; исполнитель: Engineer (engineer). Причина: Возобновление работ по требованию инженера. Прежний исход: cancelled (Closed 2026-10-22T11:28:37+03:00). История закрытия и приёмки сохранена в материалах карточки и неизменна.
