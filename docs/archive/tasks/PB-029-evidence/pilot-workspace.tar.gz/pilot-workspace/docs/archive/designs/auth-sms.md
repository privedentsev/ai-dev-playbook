# Архитектура SMS-аутентификации

<!-- playbook-meta:start -->
```json
{
  "schema_version": 1,
  "document_id": "design:auth-sms",
  "kind": "design",
  "state": "superseded",
  "created_at": "2026-10-22T08:00:00+03:00",
  "updated_at": "2026-10-22T11:28:32+03:00",
  "current_revision": 2,
  "relations": [
    {
      "relation": "based_on",
      "target": "spec:auth-methods"
    },
    {
      "relation": "based_on",
      "target": "adr:0010-sms-auth"
    }
  ],
  "tasks": [
    "DEV-701",
    "DEV-702"
  ],
  "changes": [],
  "materials": [
    {
      "id": "lifecycle-lc-d189f9390b436ee7",
      "role": "report",
      "source": "docs/archive/designs/auth-sms-evidence/archive-lc-d189f9390b436ee7.json",
      "storage": "local",
      "required": true,
      "immutable": true,
      "used_by": []
    }
  ],
  "archive": {
    "at": "2026-10-22T11:28:32+03:00",
    "reason": "полный вывод SMS из эксплуатации",
    "successor": null,
    "operation_id": "lc-d189f9390b436ee7",
    "original_path": "docs/designs/auth-sms.md"
  },
  "moves": [
    {
      "from": "docs/designs/auth-sms.md",
      "to": "docs/archive/designs/auth-sms.md"
    }
  ]
}
```
<!-- playbook-meta:end -->

## 1. Архитектура решения

Модуль отправки SMS переведён в legacy-режим (только существующие пользователи).
