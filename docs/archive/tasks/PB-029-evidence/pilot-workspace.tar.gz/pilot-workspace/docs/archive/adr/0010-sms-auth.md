# ADR-0010: Использование SMS

<!-- playbook-meta:start -->
```json
{
  "schema_version": 1,
  "document_id": "adr:0010-sms-auth",
  "kind": "adr",
  "state": "superseded",
  "created_at": "2026-10-22T08:00:00+03:00",
  "updated_at": "2026-10-22T11:28:32+03:00",
  "current_revision": 1,
  "relations": [],
  "tasks": [],
  "changes": [],
  "materials": [
    {
      "id": "lifecycle-lc-d189f9390b436ee7",
      "role": "report",
      "source": "docs/archive/adr/0010-sms-auth-evidence/archive-lc-d189f9390b436ee7.json",
      "storage": "local",
      "required": true,
      "immutable": true,
      "used_by": []
    }
  ],
  "archive": {
    "at": "2026-10-22T11:28:32+03:00",
    "reason": "полный вывод SMS из эксплуатации",
    "successor": null,
    "operation_id": "lc-d189f9390b436ee7",
    "original_path": "docs/adr/0010-sms-auth.md"
  },
  "moves": [
    {
      "from": "docs/adr/0010-sms-auth.md",
      "to": "docs/archive/adr/0010-sms-auth.md"
    }
  ]
}
```
<!-- playbook-meta:end -->

## 1. Контекст

Выбор второго фактора аутентификации.

## 2. Решение

Использовать SMS-коды для подтверждения входа.
