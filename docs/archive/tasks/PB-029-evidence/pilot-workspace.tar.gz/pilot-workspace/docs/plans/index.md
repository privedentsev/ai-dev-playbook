# Индекс планов

<!-- playbook-index:start -->
## Актуальные

Актуальных документов пока нет.

## Архив

| Документ | Состояние | Архивирован | Причина | Преемник | Задачи |
|---|---|---|---|---|---|
| [План поискового движка](../archive/plans/search-engine.md) | completed | 2026-10-22 | все задачи блока и аудит успешно завершены | — | [SUB-1](../archive/tasks/SUB-1.md), [SUB-2](../archive/tasks/SUB-2.md), [AUDIT-1](../archive/tasks/AUDIT-1.md) |
<!-- playbook-index:end -->
